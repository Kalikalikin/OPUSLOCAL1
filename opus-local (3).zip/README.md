# Opus Local — Offline-First Android & Web Video Studio

Opus Local is an offline-first video editing studio designed for high-performance mobile devices (Redmi Note 13 Pro 4G, Helio G99 Ultra) with low-RAM safety mode (Galaxy A07).

## Architecture & Unified Structure

- **Authoritative Root**: Single canonical project root with unified package identifier `com.opuslocal.app`.
- **Android Native Project**: `android/` directory containing complete Gradle 8.5 configuration, `compileSdk 34` (Android 14), AndroidX WebKit `WebViewAssetLoader`, and `NativeMediaBridge`.
- **Hardware Acceleration Pipeline**: `NativeVideoRenderer.kt` utilizing hardware `MediaCodec` (H.264 / AVC), surface rendering, burned-in bilingual subtitles, and direct export to Android MediaStore (`Movies/OpusLocal`).
- **Web / PWA Fallback Pipeline**: `src/services/videoRenderer.ts` using Canvas 2D + Web Audio API + MediaRecorder.
- **Persistence**: IndexedDB (`opus_local_db`) with binary blob storage and safe URI handoff via `saveMediaChunk`.
- **Content Rewards Campaign Assistant**: 100% offline rule engine for TikTok Creator Rewards, YouTube Shorts, and custom campaign briefs.

---

## 1. Web Application Commands

```bash
# Install dependencies
npm install

# Start local dev server (port 3000)
npm run dev

# Compile TypeScript and verify types
npm run lint

# Build production web bundle and copy assets directly to android/app/src/main/assets/www
npm run build
```

---

## 2. Android APK Build Commands

Prerequisites: JDK 17 and Android SDK (API 34) configured.

### Linux / macOS
```bash
cd android
./gradlew clean
./gradlew assembleDebug
# Generated APK: android/app/build/outputs/apk/debug/app-debug.apk
```

### Windows
```cmd
cd android
gradlew.bat clean
gradlew.bat assembleDebug
```

---

## 3. Native Bridge Contract

The WebView JavaScript layer connects to Kotlin via `@JavascriptInterface` on `window.AndroidBridge`:
- `isAndroidApp()`: Returns true when running inside native Android WebView.
- `renderNativeVideo(requestJson)`: Triggers hardware MediaCodec encoding.
- `cancelNativeRender()`: Safely terminates ongoing render job.
- `saveMediaChunk(clipId, fileName, chunk, isFirst, isLast)`: Streams media directly into private app storage (`files/media/`).
- `openMediaStoreUri(uriString)`: Launches native Android intent to play video in device media player.
- `validateModelFile(slotId, fileName, minSizeBytes)`: Cryptographically checks offline AI model files.
