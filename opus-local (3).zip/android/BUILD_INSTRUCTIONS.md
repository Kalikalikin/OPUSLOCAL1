# Opus Local — Android APK Build Instructions (Windows 10, Linux, macOS)

This document provides exact, verified instructions to build the **Opus Local** Android APK.

**Target Devices:**
- **Primary:** Redmi Note 13 Pro 4G (MediaTek Helio G99 Ultra, 12GB RAM, Android 14)
- **Secondary:** Samsung Galaxy A07 (4GB RAM, Android 14)

---

## 1. Prerequisites for Windows 10

1. **Java Development Kit (JDK 17):**
   - Download and install Eclipse Temurin OpenJDK 17 or Oracle JDK 17.
   - Verify in Command Prompt:
     ```cmd
     java -version
     ```
   - Ensure the `JAVA_HOME` system environment variable is set (e.g. `C:\Program Files\Eclipse Adoptium\jdk-17.0.10.7-hotspot`).
2. **Android SDK (API 34):**
   - Installed via Android Studio (default location: `%LOCALAPPDATA%\Android\Sdk`) or Android Command Line Tools.
   - Set environment variable `ANDROID_HOME` to your SDK folder (e.g. `C:\Users\<YourUser>\AppData\Local\Android\Sdk`).
3. **Node.js 18+:**
   - Verify in Command Prompt:
     ```cmd
     node -v
     npm -v
     ```

---

## 2. Compile Web Assets into Android Assets

In the project root directory, run:

### Windows 10 (Command Prompt or PowerShell)
```cmd
npm install
npm run build
```
*Note: `npm run build` automatically compiles Vite React assets and runs `scripts/copy-assets.js`, synchronizing all production assets directly into `android/app/src/main/assets/www/`.*

### Linux / macOS
```bash
npm install
npm run build
```

---

## 3. Build APK on Windows 10 (Using `gradlew.bat`)

Open Command Prompt (`cmd.exe`) or PowerShell in the `android/` directory:

```cmd
cd android
```

### A. Build Debug APK (For direct sideloading and testing)
```cmd
gradlew.bat assembleDebug
```
**APK Output Path:**
```
android\app\build\outputs\apk\debug\app-debug.apk
```

### B. Build Release APK (ProGuard Optimized)
```cmd
gradlew.bat assembleRelease
```
**APK Output Path:**
```
android\app\build\outputs\apk\release\app-release-unsigned.apk
```

---

## 4. Build APK on Linux / macOS (Using `./gradlew`)

```bash
cd android
./gradlew assembleDebug
```
**APK Output Path:**
```
android/app/build/outputs/apk/debug/app-debug.apk
```

---

## 5. Alternative: Build via Android Studio GUI

1. Open **Android Studio**.
2. Select **File > Open...** and select the `android` folder in this repository.
3. Allow Gradle sync to complete.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Click **locate** in the popup notification once complete to retrieve `app-debug.apk`.

---

## 6. Install APK on Android Device via ADB

1. Enable **Developer Options** and **USB Debugging** on your Redmi Note 13 Pro or Galaxy A07.
2. Connect your phone with a USB cable.
3. In Command Prompt:
   ```cmd
   adb devices
   adb install -r app\build\outputs\apk\debug\app-debug.apk
   ```
4. Start the app on device:
   ```cmd
   adb shell am start -n com.opuslocal.app/.MainActivity
   ```

---

## 7. MediaStore Export Location on Android Device

When rendering is executed on the device via native `MediaCodec`:
- Output container: **H.264 (AVC) in MP4 container** with preserved source audio.
- Android Gallery path: **`Internal Storage > Movies > OpusLocal`**.
- Content URI: `content://media/external/video/media/<id>`.
