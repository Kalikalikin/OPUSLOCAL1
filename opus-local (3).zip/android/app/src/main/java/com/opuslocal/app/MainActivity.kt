package com.opuslocal.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.*
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.webkit.WebViewAssetLoader
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null
    private var nativeRenderer: NativeVideoRenderer? = null

    // Permission launcher for Android 14 / Tiramisu and older
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.entries.all { it.value }
        val jsCall = "if (window.onPermissionResult) { window.onPermissionResult($allGranted); }"
        webView.post { webView.evaluateJavascript(jsCall, null) }
    }

    // Media file picker launcher
    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data = result.data
            val results = when {
                data?.clipData != null -> {
                    val count = data.clipData!!.itemCount
                    Array(count) { i -> data.clipData!!.getItemAt(i).uri }
                }
                data?.data != null -> arrayOf(data.data!!)
                else -> null
            }
            fileUploadCallback?.onReceiveValue(results)
        } else {
            fileUploadCallback?.onReceiveValue(null)
        }
        fileUploadCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Keep screen on during rendering and editing
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // AssetLoader securely loads local web assets without CORS or file:// limitations
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                allowFileAccess = true
                allowContentAccess = true
                mediaPlaybackRequiresUserGesture = false
                loadsImagesAutomatically = true
                useWideViewPort = true
                loadWithOverviewMode = true
                cacheMode = WebSettings.LOAD_DEFAULT
            }

            // Enable hardware acceleration
            setLayerType(View.LAYER_TYPE_HARDWARE, null)

            // Register native bridge under both canonical alias and legacy name
            val nativeBridge = NativeMediaBridge(this@MainActivity)
            addJavascriptInterface(nativeBridge, "AndroidBridge")
            addJavascriptInterface(nativeBridge, "AndroidMediaBridge")

            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    fileUploadCallback?.onReceiveValue(null)
                    fileUploadCallback = filePathCallback

                    val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                        type = "*/*"
                        putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("video/*", "image/*", "text/*"))
                    }

                    try {
                        filePickerLauncher.launch(intent)
                    } catch (e: Exception) {
                        fileUploadCallback?.onReceiveValue(null)
                        fileUploadCallback = null
                        return false
                    }
                    return true
                }
            }

            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView?,
                    request: WebResourceRequest?
                ): WebResourceResponse? {
                    return request?.url?.let { assetLoader.shouldInterceptRequest(it) }
                }

                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    return false
                }
            }
        }

        setContentView(webView)

        // Load packaged application index
        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
    }

    fun requestAppPermissions() {
        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            arrayOf(
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
            )
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_IMAGES
            )
        } else {
            arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
        }
        permissionLauncher.launch(permissions)
    }

    fun startNativeRender(requestJson: String) {
        nativeRenderer = NativeVideoRenderer(this)
        lifecycleScope.launch {
            nativeRenderer?.render(requestJson, object : NativeVideoRenderer.RenderCallback {
                override fun onProgress(
                    percent: Int,
                    currentSecond: Float,
                    totalSecond: Float,
                    status: String
                ) {
                    val escapedStatus = status.replace("'", "\\'")
                    val js = "if (window.onNativeRenderProgress) { window.onNativeRenderProgress($percent, $currentSecond, $totalSecond, '$escapedStatus'); }"
                    webView.post { webView.evaluateJavascript(js, null) }
                }

                override fun onComplete(
                    mediaStoreUri: String,
                    filePath: String,
                    fileSizeMb: Float
                ) {
                    val escapedUri = mediaStoreUri.replace("'", "\\'")
                    val escapedPath = filePath.replace("'", "\\'")
                    val js = "if (window.onNativeRenderComplete) { window.onNativeRenderComplete('$escapedUri', '$escapedPath', $fileSizeMb); }"
                    webView.post { webView.evaluateJavascript(js, null) }
                }

                override fun onError(error: String) {
                    val escapedErr = error.replace("'", "\\'")
                    val js = "if (window.onNativeRenderError) { window.onNativeRenderError('$escapedErr'); }"
                    webView.post { webView.evaluateJavascript(js, null) }
                }
            })
        }
    }

    fun cancelNativeRender() {
        nativeRenderer?.cancel()
    }

    fun openMediaStoreUri(uriString: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(Uri.parse(uriString), "video/mp4")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open video player: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
