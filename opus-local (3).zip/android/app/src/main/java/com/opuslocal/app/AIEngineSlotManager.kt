package com.opuslocal.app

import android.content.Context
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest

/**
 * AIEngineSlotManager
 * Native Android offline model storage and integrity verification manager.
 * Prepared for loading .tflite (MediaPipe/TensorFlow Lite), .onnx (ONNX Runtime Mobile),
 * and .gguf (llama.cpp / whisper.cpp) weights when deployed on device.
 */
class AIEngineSlotManager(private val context: Context) {

    private val modelsDirectory: File by lazy {
        File(context.filesDir, "models").apply {
            if (!exists()) mkdirs()
        }
    }

    enum class EngineSlot(val slotId: String, val expectedFilename: String) {
        SPEECH_RECOGNITION("speech_recognition", "whisper-base-int8.tflite"),
        TRANSCRIPTION("transcription", "arabic_english_multilingual_int8.onnx"),
        OFFLINE_TRANSLATION("offline_translation", "opus_mt_ar_en_quantized.onnx"),
        CLIP_DETECTION("clip_detection", "highlight_detector_v1_int8.tflite"),
        SMART_REFRAMING("smart_reframing", "mediapipe_face_mesh_fp16.tflite"),
        CAMPAIGN_AGENT("campaign_agent", "campaign_agent_q4_k_m.gguf"),
        COMPLIANCE_CHECKER("compliance_checker", "compliance_ruleset_offline.onnx")
    }

    fun isEngineModelInstalled(slot: EngineSlot): Boolean {
        val modelFile = File(modelsDirectory, slot.expectedFilename)
        return modelFile.exists() && modelFile.length() > 0
    }

    fun getModelFile(slot: EngineSlot): File? {
        val file = File(modelsDirectory, slot.expectedFilename)
        return if (file.exists()) file else null
    }

    fun computeSha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { fis ->
            val buffer = ByteArray(8192)
            var bytesRead: Int
            while (fis.read(buffer).also { bytesRead = it } != -1) {
                digest.update(buffer, 0, bytesRead)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
