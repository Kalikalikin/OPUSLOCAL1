package com.opuslocal.app

import android.content.ContentValues
import android.content.Context
import android.graphics.*
import android.media.*
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer

/**
 * NativeVideoRenderer
 * Production Android hardware video rendering pipeline using MediaCodec, MediaExtractor,
 * MediaMetadataRetriever (hardware frame decoder), and MediaMuxer.
 * 
 * Capabilities:
 * 1. Decodes real source video frames from multiple clips in timeline order.
 * 2. Precision In-point and Out-point trimming and clip duration handling.
 * 3. Aspect ratio reframing (9:16 vertical, 16:9 landscape, 1:1 square, 4:5 portrait) with fit/fill/stretch.
 * 4. Burned-in bilingual subtitles (Arabic/English) rendered directly into video frames.
 * 5. Extracts and muxes original source audio from all segments.
 * 6. Encodes output to H.264 (AVC) MP4 via hardware MediaCodec.
 * 7. Saves completed output directly into Android MediaStore (Movies/OpusLocal) and returns content:// URI.
 * 8. Real-time progress reporting and non-blocking cancellation.
 */
class NativeVideoRenderer(private val context: Context) {

    companion object {
        private const val TAG = "NativeVideoRenderer"
        private const val MIME_TYPE_VIDEO = "video/avc" // H.264
        private const val TIMEOUT_USEC = 10000L
    }

    @Volatile
    private var isCancelled = false

    fun cancel() {
        isCancelled = true
    }

    interface RenderCallback {
        fun onProgress(percent: Int, currentSecond: Float, totalSecond: Float, status: String)
        fun onComplete(mediaStoreUri: String, filePath: String, fileSizeMb: Float)
        fun onError(error: String)
    }

    private data class RenderSegment(
        val sourceUri: String,
        val inPointSec: Float,
        val outPointSec: Float,
        val speed: Float,
        val volume: Float,
        val timelineStartSec: Float,
        val timelineEndSec: Float
    )

    private data class RenderSubtitle(
        val startSec: Float,
        val endSec: Float,
        val text: String,
        val textAr: String
    )

    suspend fun render(requestJson: String, callback: RenderCallback) = withContext(Dispatchers.IO) {
        isCancelled = false
        var muxer: MediaMuxer? = null
        var tempOutputFile: File? = null

        try {
            val json = JSONObject(requestJson)
            val targetWidth = json.optInt("targetWidth", json.optInt("outputWidth", 1080))
            val targetHeight = json.optInt("targetHeight", json.optInt("outputHeight", 1920))
            val scaleMode = json.optString("scaleMode", "fit")
            val fps = json.optInt("fps", 30)
            val bitrate = json.optInt("bitrate", json.optInt("bitrateBps", 6000000))
            val totalDurationSec = json.optDouble("totalDurationSec", 0.0).toFloat()
            val burnSubtitles = json.optBoolean("burnSubtitles", true)
            val title = json.optString("title", json.optString("projectName", "OpusLocal_Video_${System.currentTimeMillis()}"))

            val rawSegments = json.optJSONArray("segments") ?: json.optJSONArray("clips") ?: JSONArray()
            val rawSubtitles = json.optJSONArray("subtitles") ?: JSONArray()

            if (rawSegments.length() == 0) {
                callback.onError("Timeline has no video segments to render.")
                return@withContext
            }

            // Parse Segments with timeline positions
            val segments = mutableListOf<RenderSegment>()
            var timelineCursor = 0f
            for (i in 0 until rawSegments.length()) {
                val segObj = rawSegments.getJSONObject(i)
                val sourceUri = segObj.optString("sourceUri", "")
                
                // Support both inPointMs/outPointMs (milliseconds) and trimStartSec/trimEndSec (seconds)
                val inSec = if (segObj.has("trimStartSec")) {
                    segObj.optDouble("trimStartSec", 0.0).toFloat()
                } else {
                    segObj.optInt("inPointMs", 0) / 1000f
                }
                
                val outSec = if (segObj.has("trimEndSec")) {
                    segObj.optDouble("trimEndSec", 0.0).toFloat()
                } else {
                    segObj.optInt("outPointMs", 0) / 1000f
                }
                
                val speed = segObj.optDouble("speed", 1.0).toFloat().coerceAtLeast(0.25f)
                val isMuted = segObj.optBoolean("muted", false)
                val volume = if (isMuted) 0f else segObj.optDouble("volume", 1.0).toFloat()

                val duration = if (outSec > inSec) (outSec - inSec) / speed else 1.0f
                val segStart = timelineCursor
                val segEnd = timelineCursor + duration
                timelineCursor = segEnd

                segments.add(
                    RenderSegment(
                        sourceUri = sourceUri,
                        inPointSec = inSec,
                        outPointSec = if (outSec > inSec) outSec else inSec + 1.0f,
                        speed = speed,
                        volume = volume,
                        timelineStartSec = segStart,
                        timelineEndSec = segEnd
                    )
                )
            }

            val computedTotalDuration = if (totalDurationSec > 0f) totalDurationSec else timelineCursor
            if (computedTotalDuration <= 0f) {
                callback.onError("Project duration is zero.")
                return@withContext
            }

            // Parse Subtitles
            val subtitles = mutableListOf<RenderSubtitle>()
            for (i in 0 until rawSubtitles.length()) {
                val subObj = rawSubtitles.getJSONObject(i)
                val start = subObj.optDouble("startSec", subObj.optDouble("startTimeSec", 0.0)).toFloat()
                val end = subObj.optDouble("endSec", subObj.optDouble("endTimeSec", 0.0)).toFloat()
                subtitles.add(
                    RenderSubtitle(
                        startSec = start,
                        endSec = end,
                        text = subObj.optString("text", ""),
                        textAr = subObj.optString("textAr", "")
                    )
                )
            }

            callback.onProgress(0, 0f, computedTotalDuration, "Preparing Hardware MediaCodec...")

            tempOutputFile = File(context.cacheDir, "opus_render_${System.currentTimeMillis()}.mp4")
            if (tempOutputFile.exists()) tempOutputFile.delete()

            muxer = MediaMuxer(tempOutputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            // 1. Initialize Video Encoder (H.264 / AVC)
            val videoFormat = MediaFormat.createVideoFormat(MIME_TYPE_VIDEO, targetWidth, targetHeight).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1) // 1s keyframes
            }

            val videoEncoder = MediaCodec.createEncoderByType(MIME_TYPE_VIDEO)
            videoEncoder.configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val inputSurface = videoEncoder.createInputSurface()
            videoEncoder.start()

            // 2. Discover and add audio track from source clips if available
            var sourceAudioFormat: MediaFormat? = null
            for (seg in segments) {
                if (seg.sourceUri.isNotEmpty()) {
                    try {
                        val extractor = MediaExtractor()
                        setExtractorSource(extractor, seg.sourceUri)
                        for (t in 0 until extractor.trackCount) {
                            val format = extractor.getTrackFormat(t)
                            val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                            if (mime.startsWith("audio/")) {
                                sourceAudioFormat = format
                                break
                            }
                        }
                        extractor.release()
                        if (sourceAudioFormat != null) break
                    } catch (e: Exception) {
                        Log.w(TAG, "Audio format probe skipped for ${seg.sourceUri}: ${e.message}")
                    }
                }
            }

            var videoTrackIndex = -1
            var audioTrackIndex = -1
            var muxerStarted = false
            val bufferInfo = MediaCodec.BufferInfo()

            // 3. Pre-create decoders/retrievers for each unique source
            val retrievers = mutableMapOf<String, MediaMetadataRetriever>()
            for (seg in segments) {
                if (seg.sourceUri.isNotEmpty() && !retrievers.containsKey(seg.sourceUri)) {
                    try {
                        val retriever = MediaMetadataRetriever()
                        setRetrieverSource(retriever, seg.sourceUri)
                        retrievers[seg.sourceUri] = retriever
                    } catch (e: Exception) {
                        Log.w(TAG, "Retriever initialization warning for ${seg.sourceUri}: ${e.message}")
                    }
                }
            }

            // Paints for frame composition & subtitles
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            val subtitleTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = targetWidth * 0.045f
                textAlign = Paint.Align.CENTER
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                setShadowLayer(4f, 2f, 2f, Color.BLACK)
            }
            val subtitleBgPaint = Paint().apply {
                color = Color.parseColor("#D9000000") // 85% translucent black box
            }

            val totalFrames = (computedTotalDuration * fps).toInt()
            val frameDeltaUs = 1000000L / fps

            var lastDecodedBitmap: Bitmap? = null

            // 4. Video Frame Rendering Loop
            for (frameIndex in 0 until totalFrames) {
                if (isCancelled) {
                    callback.onProgress(0, 0f, computedTotalDuration, "Cancelled")
                    break
                }

                val currentTimelineSec = frameIndex.toFloat() / fps

                // Find active segment at current timeline position
                val activeSeg = segments.find { currentTimelineSec >= it.timelineStartSec && currentTimelineSec < it.timelineEndSec }

                // Lock Hardware Canvas on MediaCodec Input Surface
                val canvas = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    inputSurface.lockHardwareCanvas()
                } else {
                    inputSurface.lockCanvas(null)
                }

                // Fill background
                canvas.drawColor(Color.parseColor("#090D16"))

                // Decode real source video frame
                if (activeSeg != null && retrievers.containsKey(activeSeg.sourceUri)) {
                    val retriever = retrievers[activeSeg.sourceUri]
                    if (retriever != null) {
                        val offsetInSeg = (currentTimelineSec - activeSeg.timelineStartSec) * activeSeg.speed
                        val sourceTimeSec = activeSeg.inPointSec + offsetInSeg
                        val sourceTimeUs = (sourceTimeSec * 1000000L).toLong()

                        val frameBitmap: Bitmap? = try {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                                retriever.getScaledFrameAtTime(sourceTimeUs, MediaMetadataRetriever.OPTION_CLOSEST, targetWidth, targetHeight)
                            } else {
                                retriever.getFrameAtTime(sourceTimeUs, MediaMetadataRetriever.OPTION_CLOSEST)
                            }
                        } catch (e: Exception) {
                            null
                        }

                        val bitmapToDraw = frameBitmap ?: lastDecodedBitmap
                        if (bitmapToDraw != null) {
                            drawFrameScaled(canvas, bitmapToDraw, targetWidth, targetHeight, scaleMode, paint)
                            if (frameBitmap != null) {
                                if (lastDecodedBitmap != null && lastDecodedBitmap != frameBitmap) {
                                    lastDecodedBitmap?.recycle()
                                }
                                lastDecodedBitmap = frameBitmap
                            }
                        }
                    }
                } else if (lastDecodedBitmap != null) {
                    drawFrameScaled(canvas, lastDecodedBitmap!!, targetWidth, targetHeight, scaleMode, paint)
                }

                // Burn-in Subtitles
                if (burnSubtitles) {
                    val activeSub = subtitles.find { currentTimelineSec >= it.startSec && currentTimelineSec <= it.endSec }
                    if (activeSub != null) {
                        val text = if (activeSub.textAr.isNotEmpty()) activeSub.textAr else activeSub.text
                        val textBounds = Rect()
                        subtitleTextPaint.getTextBounds(text, 0, text.length, textBounds)

                        val cx = targetWidth / 2f
                        val padX = 28f
                        val padY = 18f
                        val subY = targetHeight * 0.84f
                        val rectF = RectF(
                            cx - (textBounds.width() / 2f) - padX,
                            subY - textBounds.height() - padY,
                            cx + (textBounds.width() / 2f) + padX,
                            subY + padY
                        )
                        canvas.drawRoundRect(rectF, 14f, 14f, subtitleBgPaint)
                        canvas.drawText(text, cx, subY, subtitleTextPaint)
                    }
                }

                inputSurface.unlockCanvasAndPost(canvas)

                // Drain Encoder Output
                while (true) {
                    val encoderStatus = videoEncoder.dequeueOutputBuffer(bufferInfo, TIMEOUT_USEC)
                    if (encoderStatus == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        break
                    } else if (encoderStatus == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        if (muxerStarted) {
                            throw IllegalStateException("Format changed after muxer started")
                        }
                        val newVideoFormat = videoEncoder.outputFormat
                        videoTrackIndex = muxer.addTrack(newVideoFormat)

                        if (sourceAudioFormat != null) {
                            audioTrackIndex = muxer.addTrack(sourceAudioFormat)
                        }

                        muxer.start()
                        muxerStarted = true
                    } else if (encoderStatus >= 0) {
                        val encodedData = videoEncoder.getOutputBuffer(encoderStatus)
                            ?: throw IllegalStateException("Encoder output buffer $encoderStatus was null")

                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                            bufferInfo.size = 0
                        }

                        if (bufferInfo.size != 0 && muxerStarted) {
                            encodedData.position(bufferInfo.offset)
                            encodedData.limit(bufferInfo.offset + bufferInfo.size)
                            muxer.writeSampleData(videoTrackIndex, encodedData, bufferInfo)
                        }

                        videoEncoder.releaseOutputBuffer(encoderStatus, false)
                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                            break
                        }
                    }
                }

                val percent = Math.min(95, ((currentTimelineSec / computedTotalDuration) * 100).toInt())
                callback.onProgress(percent, currentTimelineSec, computedTotalDuration, "Encoding H.264 frames...")
            }

            // Signal End of Stream to Encoder
            videoEncoder.signalEndOfInputStream()

            // Drain remaining buffers from encoder
            while (true) {
                val encoderStatus = videoEncoder.dequeueOutputBuffer(bufferInfo, TIMEOUT_USEC)
                if (encoderStatus == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    break
                } else if (encoderStatus >= 0) {
                    val encodedData = videoEncoder.getOutputBuffer(encoderStatus) ?: break
                    if (bufferInfo.size != 0 && muxerStarted) {
                        encodedData.position(bufferInfo.offset)
                        encodedData.limit(bufferInfo.offset + bufferInfo.size)
                        muxer.writeSampleData(videoTrackIndex, encodedData, bufferInfo)
                    }
                    videoEncoder.releaseOutputBuffer(encoderStatus, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                }
            }

            // Release Video Decoders & Encoders
            retrievers.values.forEach {
                try { it.release() } catch (ignored: Exception) {}
            }
            lastDecodedBitmap?.recycle()
            videoEncoder.stop()
            videoEncoder.release()

            // 5. Audio Extraction & Sequential Muxing from source segments
            if (muxerStarted && audioTrackIndex >= 0) {
                callback.onProgress(96, computedTotalDuration, computedTotalDuration, "Muxing source audio...")
                val audioBuf = ByteBuffer.allocate(128 * 1024)
                val audioBufferInfo = MediaCodec.BufferInfo()
                var accumulatedAudioTimeUs = 0L

                for (seg in segments) {
                    if (seg.sourceUri.isEmpty()) continue
                    try {
                        val extractor = MediaExtractor()
                        setExtractorSource(extractor, seg.sourceUri)

                        var segmentAudioTrack = -1
                        for (t in 0 until extractor.trackCount) {
                            val format = extractor.getTrackFormat(t)
                            val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                            if (mime.startsWith("audio/")) {
                                segmentAudioTrack = t
                                extractor.selectTrack(t)
                                break
                            }
                        }

                        if (segmentAudioTrack >= 0) {
                            val inPointUs = (seg.inPointSec * 1000000L).toLong()
                            val outPointUs = (seg.outPointSec * 1000000L).toLong()
                            extractor.seekTo(inPointUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)

                            var firstSampleTimeUs = -1L
                            while (true) {
                                val sampleSize = extractor.readSampleData(audioBuf, 0)
                                if (sampleSize < 0) break

                                val currentSampleTime = extractor.sampleTime
                                if (currentSampleTime > outPointUs) break

                                if (firstSampleTimeUs < 0) {
                                    firstSampleTimeUs = currentSampleTime
                                }

                                val relativeSampleTimeUs = currentSampleTime - firstSampleTimeUs
                                audioBufferInfo.offset = 0
                                audioBufferInfo.size = sampleSize
                                audioBufferInfo.presentationTimeUs = accumulatedAudioTimeUs + relativeSampleTimeUs
                                audioBufferInfo.flags = extractor.sampleFlags

                                muxer.writeSampleData(audioTrackIndex, audioBuf, audioBufferInfo)
                                extractor.advance()
                            }

                            val segDurationUs = ((seg.outPointSec - seg.inPointSec) * 1000000L).toLong()
                            accumulatedAudioTimeUs += segDurationUs
                        }

                        extractor.release()
                    } catch (e: Exception) {
                        Log.w(TAG, "Audio extraction warning for segment ${seg.sourceUri}: ${e.message}")
                    }
                }
            }

            if (muxerStarted) {
                muxer.stop()
                muxer.release()
                muxer = null
            }

            if (isCancelled) {
                tempOutputFile.delete()
                callback.onError("Render was cancelled by user.")
                return@withContext
            }

            // 6. Save to Android MediaStore
            callback.onProgress(99, computedTotalDuration, computedTotalDuration, "Saving to Android MediaStore...")
            val mediaStoreUri = saveToMediaStore(tempOutputFile, "$title.mp4")
            val fileSizeMb = tempOutputFile.length() / (1024f * 1024f)

            callback.onProgress(100, computedTotalDuration, computedTotalDuration, "Completed")
            callback.onComplete(mediaStoreUri.toString(), tempOutputFile.absolutePath, fileSizeMb)

        } catch (e: Exception) {
            Log.e(TAG, "Native video render failed: ${e.message}", e)
            callback.onError("Native render failed: ${e.message}")
        } finally {
            try { muxer?.release() } catch (ignored: Exception) {}
        }
    }

    private fun setExtractorSource(extractor: MediaExtractor, sourceUri: String) {
        if (sourceUri.startsWith("content://")) {
            extractor.setDataSource(context, Uri.parse(sourceUri), null)
        } else {
            val path = sourceUri.removePrefix("file://")
            extractor.setDataSource(path)
        }
    }

    private fun setRetrieverSource(retriever: MediaMetadataRetriever, sourceUri: String) {
        if (sourceUri.startsWith("content://")) {
            retriever.setDataSource(context, Uri.parse(sourceUri))
        } else {
            val path = sourceUri.removePrefix("file://")
            retriever.setDataSource(path)
        }
    }

    private fun drawFrameScaled(
        canvas: Canvas,
        bitmap: Bitmap,
        targetWidth: Int,
        targetHeight: Int,
        scaleMode: String,
        paint: Paint
    ) {
        val srcW = bitmap.width.toFloat()
        val srcH = bitmap.height.toFloat()
        val canvasRatio = targetWidth.toFloat() / targetHeight.toFloat()
        val videoRatio = srcW / srcH

        val matrix = Matrix()
        when (scaleMode) {
            "fill" -> {
                val scale = if (videoRatio > canvasRatio) {
                    targetHeight.toFloat() / srcH
                } else {
                    targetWidth.toFloat() / srcW
                }
                matrix.postScale(scale, scale)
                val dx = (targetWidth - srcW * scale) / 2f
                val dy = (targetHeight - srcH * scale) / 2f
                matrix.postTranslate(dx, dy)
            }
            "stretch" -> {
                matrix.postScale(targetWidth.toFloat() / srcW, targetHeight.toFloat() / srcH)
            }
            else -> { // "fit" (letterboxed)
                val scale = if (videoRatio > canvasRatio) {
                    targetWidth.toFloat() / srcW
                } else {
                    targetHeight.toFloat() / srcH
                }
                matrix.postScale(scale, scale)
                val dx = (targetWidth - srcW * scale) / 2f
                val dy = (targetHeight - srcH * scale) / 2f
                matrix.postTranslate(dx, dy)
            }
        }
        canvas.drawBitmap(bitmap, matrix, paint)
    }

    private fun saveToMediaStore(sourceFile: File, displayName: String): Uri {
        val resolver = context.contentResolver
        val contentValues = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/OpusLocal")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }

        val collectionUri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }

        val itemUri = resolver.insert(collectionUri, contentValues)
            ?: throw IllegalStateException("Could not create MediaStore entry for video export.")

        resolver.openOutputStream(itemUri).use { outStream ->
            if (outStream == null) throw IllegalStateException("Could not open output stream to MediaStore.")
            FileInputStream(sourceFile).use { inStream ->
                inStream.copyTo(outStream)
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            contentValues.clear()
            contentValues.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(itemUri, contentValues, null, null)
        }

        return itemUri
    }
}
