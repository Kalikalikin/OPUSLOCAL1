# ProGuard rules for Opus Local Android
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

-keep class com.opuslocal.app.NativeMediaBridge { *; }
-keep class com.opuslocal.app.AIEngineSlotManager { *; }

# Keep WebKit and Chrome client classes
-keep class androidx.webkit.** { *; }
-dontwarn androidx.webkit.**

# Prevent obfuscation of JNI and native libraries for future TFLite / ONNX runtime
-keepclasseswithmembernames class * {
    native <methods>;
}
