/**
 * Content Rewards Campaign Agent & Compliance Engine
 * 100% Offline Rule Engine & NLP Parser for Video Creator Campaigns
 * Analyzes briefs, audits timelines against requirements, generates compliance plans,
 * and executes automated timeline fixes.
 */

import { Project, TimelineSegment, SubtitleItem, AspectRatioType } from '../types/project';

export interface CampaignRequirement {
  id: string;
  category: 'format' | 'duration' | 'content' | 'legal' | 'hashtags';
  title: string;
  description: string;
  ruleType: 'aspect_ratio' | 'min_duration' | 'max_duration' | 'keyword' | 'hashtag' | 'prohibited_phrase' | 'hook_speed';
  expectedValue: any;
  severity: 'critical' | 'warning' | 'recommendation';
}

export interface CampaignBrief {
  id: string;
  name: string;
  platform: 'tiktok' | 'youtube_shorts' | 'instagram_reels' | 'custom';
  description: string;
  rawBriefText: string;
  requirements: CampaignRequirement[];
}

export interface ComplianceCheckResult {
  requirementId: string;
  category: 'format' | 'duration' | 'content' | 'legal' | 'hashtags';
  title: string;
  status: 'passed' | 'failed' | 'warning';
  currentValueDescription: string;
  expectedValueDescription: string;
  fixActionAvailable: boolean;
  fixActionType?: 'reframe_aspect' | 'inject_hashtag' | 'trim_duration' | 'remove_phrase';
  details: string;
}

export interface CampaignAuditReport {
  timestamp: string;
  briefName: string;
  platform: string;
  overallScore: number; // 0 - 100
  status: 'compliant' | 'needs_action' | 'rejected';
  summary: {
    totalRules: number;
    passed: number;
    failedCritical: number;
    warnings: number;
  };
  checks: ComplianceCheckResult[];
  legalDisclaimer: string;
}

export const CAMPAIGN_TEMPLATES: CampaignBrief[] = [
  {
    id: 'tiktok_rewards',
    name: 'TikTok Creator Rewards Program',
    platform: 'tiktok',
    description: 'Requires original vertical video (9:16), minimum 1 minute (60s), high retention hook.',
    rawBriefText: 'Must be 9:16 vertical format. Duration must be at least 60 seconds (1 minute+). High engagement hook in first 3s. No watermarks. Must contain #creatorrewards.',
    requirements: [
      {
        id: 'tt_aspect',
        category: 'format',
        title: 'Vertical 9:16 Aspect Ratio',
        description: 'TikTok rewards algorithm strictly demands full vertical 9:16 viewport.',
        ruleType: 'aspect_ratio',
        expectedValue: '9:16',
        severity: 'critical'
      },
      {
        id: 'tt_duration',
        category: 'duration',
        title: 'Minimum 60 Seconds Duration',
        description: 'Creator Rewards qualification threshold requires >= 60.0s elapsed timeline.',
        ruleType: 'min_duration',
        expectedValue: 60.0,
        severity: 'critical'
      },
      {
        id: 'tt_hook',
        category: 'content',
        title: 'Immediate Hook in First 3 Seconds',
        description: 'Initial subtitle or speech trigger within 3.0s to minimize drop-off.',
        ruleType: 'hook_speed',
        expectedValue: 3.0,
        severity: 'warning'
      },
      {
        id: 'tt_hashtag',
        category: 'hashtags',
        title: 'Mandatory Campaign Tag',
        description: 'Subtitle / caption should mention #creatorrewards or #tiktokrewards.',
        ruleType: 'hashtag',
        expectedValue: ['#creatorrewards', '#tiktokrewards', '#opuslocal'],
        severity: 'warning'
      }
    ]
  },
  {
    id: 'yt_shorts',
    name: 'YouTube Shorts Monetization',
    platform: 'youtube_shorts',
    description: 'Vertical 9:16 format, maximum duration 60 seconds, no third-party watermark.',
    rawBriefText: 'Strict 9:16 aspect ratio. Maximum duration 60.0 seconds. No external app watermarks or unoriginal content.',
    requirements: [
      {
        id: 'yt_aspect',
        category: 'format',
        title: 'Vertical 9:16 Aspect Ratio',
        description: 'Shorts shelf requires 9:16 portrait ratio.',
        ruleType: 'aspect_ratio',
        expectedValue: '9:16',
        severity: 'critical'
      },
      {
        id: 'yt_duration',
        category: 'duration',
        title: 'Maximum 60 Seconds Duration',
        description: 'Shorts cannot exceed 60.0 seconds or will be classified as regular video.',
        ruleType: 'max_duration',
        expectedValue: 60.0,
        severity: 'critical'
      },
      {
        id: 'yt_prohibited',
        category: 'legal',
        title: 'No Prohibited Third-Party Watermarks',
        description: 'Disallows mentions or watermarks from rival short-form platforms.',
        ruleType: 'prohibited_phrase',
        expectedValue: ['tiktok watermark', 'capcut template', 'repost'],
        severity: 'warning'
      }
    ]
  },
  {
    id: 'brand_sponsored',
    name: 'Sponsored Creator Campaign Brief',
    platform: 'custom',
    description: 'Commercial brand campaign with FTC / advertising disclosure (#ad, #sponsored).',
    rawBriefText: 'Requires clear commercial disclosure #ad or #sponsored in subtitles/captions. 9:16 vertical format, 30-60 seconds. Must include Call to Action.',
    requirements: [
      {
        id: 'brand_aspect',
        category: 'format',
        title: 'Vertical 9:16 Format',
        description: 'Social sponsor delivery requires mobile vertical format.',
        ruleType: 'aspect_ratio',
        expectedValue: '9:16',
        severity: 'critical'
      },
      {
        id: 'brand_disclosure',
        category: 'legal',
        title: 'FTC Disclosure (#ad / #sponsored)',
        description: 'Regulatory compliance requires prominent sponsor identification in subtitles.',
        ruleType: 'hashtag',
        expectedValue: ['#ad', '#sponsored', '#partner', 'إعلان', 'برعاية'],
        severity: 'critical'
      },
      {
        id: 'brand_min_duration',
        category: 'duration',
        title: 'Minimum Duration (30s)',
        description: 'Sponsor deliverables require at least 30 seconds of content.',
        ruleType: 'min_duration',
        expectedValue: 30.0,
        severity: 'critical'
      },
      {
        id: 'brand_max_duration',
        category: 'duration',
        title: 'Maximum Duration (60s)',
        description: 'Deliverable must fit short-form distribution under 60 seconds.',
        ruleType: 'max_duration',
        expectedValue: 60.0,
        severity: 'warning'
      },
      {
        id: 'brand_cta',
        category: 'content',
        title: 'Call to Action Mention',
        description: 'Subtitles should reference call-to-action (e.g. link in bio, coupon, رابط).',
        ruleType: 'keyword',
        expectedValue: ['link in bio', 'code', 'discount', 'bio', 'رابط', 'خصم', 'كوبون'],
        severity: 'warning'
      }
    ]
  }
];

export class CampaignAgentService {
  /**
   * Parses natural language brief text offline using rule extraction
   */
  public static parseCustomBrief(rawText: string, name: string = 'Custom Campaign'): CampaignBrief {
    const requirements: CampaignRequirement[] = [];
    const lower = rawText.toLowerCase();

    // 1. Aspect Ratio extraction
    if (lower.includes('9:16') || lower.includes('vertical') || lower.includes('portrait') || lower.includes('عمودي')) {
      requirements.push({
        id: 'custom_aspect',
        category: 'format',
        title: 'Vertical 9:16 Aspect Ratio',
        description: 'Brief indicates vertical format requirement.',
        ruleType: 'aspect_ratio',
        expectedValue: '9:16',
        severity: 'critical'
      });
    } else if (lower.includes('16:9') || lower.includes('horizontal') || lower.includes('landscape') || lower.includes('أفقي')) {
      requirements.push({
        id: 'custom_aspect',
        category: 'format',
        title: 'Horizontal 16:9 Aspect Ratio',
        description: 'Brief indicates landscape format requirement.',
        ruleType: 'aspect_ratio',
        expectedValue: '16:9',
        severity: 'critical'
      });
    } else if (lower.includes('1:1') || lower.includes('square') || lower.includes('مربع')) {
      requirements.push({
        id: 'custom_aspect',
        category: 'format',
        title: 'Square 1:1 Aspect Ratio',
        description: 'Brief indicates square 1:1 format requirement.',
        ruleType: 'aspect_ratio',
        expectedValue: '1:1',
        severity: 'critical'
      });
    }

    // 2. Minimum duration extraction (e.g. "at least 60 seconds", "min 1 min", "60s+")
    const minMatch = lower.match(/(?:at least|minimum|min|أكثر من|لا يقل عن)\s*(\d+)\s*(?:s|sec|seconds|ثانية|min|minutes|دقيقة)?/i);
    if (minMatch) {
      let val = parseInt(minMatch[1], 10);
      if (lower.includes('min') && val < 10) val *= 60; // convert minutes to seconds
      requirements.push({
        id: 'custom_min_duration',
        category: 'duration',
        title: `Minimum Duration (>= ${val}s)`,
        description: `Brief mandates a minimum running duration of ${val} seconds.`,
        ruleType: 'min_duration',
        expectedValue: val,
        severity: 'critical'
      });
    }

    // 3. Maximum duration extraction (e.g. "under 60s", "max 90s")
    const maxMatch = lower.match(/(?:under|maximum|max|less than|أقل من|لا يزيد عن)\s*(\d+)\s*(?:s|sec|seconds|ثانية|min|minutes|دقيقة)?/i);
    if (maxMatch) {
      let val = parseInt(maxMatch[1], 10);
      if (lower.includes('min') && val < 10) val *= 60;
      requirements.push({
        id: 'custom_max_duration',
        category: 'duration',
        title: `Maximum Duration (<= ${val}s)`,
        description: `Brief restricts total duration to ${val} seconds.`,
        ruleType: 'max_duration',
        expectedValue: val,
        severity: 'critical'
      });
    }

    // 4. Hashtags extraction (e.g. #campaign #brand)
    const hashtagMatches = rawText.match(/#[a-zA-Z0-9_\u0600-\u06FF]+/g);
    if (hashtagMatches && hashtagMatches.length > 0) {
      requirements.push({
        id: 'custom_hashtags',
        category: 'hashtags',
        title: 'Required Hashtags',
        description: `Must include campaign tags: ${hashtagMatches.join(' ')}`,
        ruleType: 'hashtag',
        expectedValue: hashtagMatches,
        severity: 'critical'
      });
    }

    // 5. Commercial disclosure rule if keywords present
    if (lower.includes('sponsor') || lower.includes('ad') || lower.includes('إعلان') || lower.includes('commercial')) {
      requirements.push({
        id: 'custom_disclosure',
        category: 'legal',
        title: 'Sponsorship Disclosure',
        description: 'Clear commercial disclosure required in subtitle text.',
        ruleType: 'hashtag',
        expectedValue: ['#ad', '#sponsored', '#partner', 'إعلان', 'برعاية'],
        severity: 'critical'
      });
    }

    return {
      id: `custom_${Date.now()}`,
      name,
      platform: 'custom',
      description: 'Custom Creator Brief configured by user.',
      rawBriefText: rawText,
      requirements: requirements.length > 0 ? requirements : CAMPAIGN_TEMPLATES[0].requirements
    };
  }

  /**
   * Audits active project timeline and subtitles against the campaign brief
   */
  public static auditProject(
    project: Project,
    segments: TimelineSegment[],
    subtitles: SubtitleItem[],
    brief: CampaignBrief
  ): CampaignAuditReport {
    const totalDuration = segments.reduce((max, s) => Math.max(max, s.endTime), 0);
    const combinedSubtitleText = subtitles
      .map(s => `${s.text} ${s.textAr || ''}`)
      .join(' ')
      .toLowerCase();

    const checks: ComplianceCheckResult[] = [];

    for (const req of brief.requirements) {
      switch (req.ruleType) {
        case 'aspect_ratio': {
          const pass = project.aspectRatio === req.expectedValue;
          checks.push({
            requirementId: req.id,
            category: req.category,
            title: req.title,
            status: pass ? 'passed' : req.severity === 'critical' ? 'failed' : 'warning',
            currentValueDescription: `Current: ${project.aspectRatio}`,
            expectedValueDescription: `Required: ${req.expectedValue}`,
            fixActionAvailable: !pass,
            fixActionType: 'reframe_aspect',
            details: pass
              ? `Project aspect ratio matches campaign requirement (${req.expectedValue}).`
              : `Current canvas is ${project.aspectRatio}. Tap "Apply Fix" to reframe to ${req.expectedValue}.`
          });
          break;
        }

        case 'min_duration': {
          const minSec = Number(req.expectedValue);
          const pass = totalDuration >= minSec;
          checks.push({
            requirementId: req.id,
            category: req.category,
            title: req.title,
            status: pass ? 'passed' : req.severity === 'critical' ? 'failed' : 'warning',
            currentValueDescription: `Current: ${totalDuration.toFixed(1)}s`,
            expectedValueDescription: `Min: ${minSec.toFixed(1)}s`,
            fixActionAvailable: false,
            details: pass
              ? `Duration meets minimum criteria (${totalDuration.toFixed(1)}s >= ${minSec}s).`
              : `Timeline is only ${totalDuration.toFixed(1)}s long, which falls short of the required ${minSec}s threshold.`
          });
          break;
        }

        case 'max_duration': {
          const maxSec = Number(req.expectedValue);
          const pass = totalDuration <= maxSec + 0.5; // 0.5s margin
          checks.push({
            requirementId: req.id,
            category: req.category,
            title: req.title,
            status: pass ? 'passed' : req.severity === 'critical' ? 'failed' : 'warning',
            currentValueDescription: `Current: ${totalDuration.toFixed(1)}s`,
            expectedValueDescription: `Max: ${maxSec.toFixed(1)}s`,
            fixActionAvailable: !pass,
            fixActionType: 'trim_duration',
            details: pass
              ? `Duration is within platform bounds (${totalDuration.toFixed(1)}s <= ${maxSec}s).`
              : `Duration exceeds limit (${totalDuration.toFixed(1)}s > ${maxSec}s). Trim end to qualify.`
          });
          break;
        }

        case 'hook_speed': {
          // Check if there is a subtitle starting in first 3 seconds
          const firstSub = subtitles.length > 0 ? subtitles[0] : null;
          const hasEarlyHook = firstSub ? firstSub.startTime <= 3.0 : false;
          checks.push({
            requirementId: req.id,
            category: req.category,
            title: req.title,
            status: hasEarlyHook ? 'passed' : 'warning',
            currentValueDescription: firstSub
              ? `First caption at ${firstSub.startTime.toFixed(1)}s`
              : 'No captions in first 3s',
            expectedValueDescription: '<= 3.0s hook',
            fixActionAvailable: false,
            details: hasEarlyHook
              ? 'Opening subtitle detected within first 3 seconds to capture viewer retention.'
              : 'No opening subtitle found in first 3 seconds. Consider adding a strong opening caption.'
          });
          break;
        }

        case 'hashtag': {
          const tags: string[] = Array.isArray(req.expectedValue) ? req.expectedValue : [req.expectedValue];
          const found = tags.some(tag => combinedSubtitleText.includes(tag.toLowerCase()));
          checks.push({
            requirementId: req.id,
            category: req.category,
            title: req.title,
            status: found ? 'passed' : req.severity === 'critical' ? 'failed' : 'warning',
            currentValueDescription: found ? 'Present in subtitles' : 'Not found in subtitles',
            expectedValueDescription: `Tags: ${tags.join(', ')}`,
            fixActionAvailable: !found,
            fixActionType: 'inject_hashtag',
            details: found
              ? `Campaign requirement satisfied: detected in subtitles.`
              : `Missing required disclosure/tag: ${tags[0]}. Tap "Apply Fix" to insert as caption.`
          });
          break;
        }

        case 'keyword': {
          const words: string[] = Array.isArray(req.expectedValue) ? req.expectedValue : [req.expectedValue];
          const found = words.some(w => combinedSubtitleText.includes(w.toLowerCase()));
          checks.push({
            requirementId: req.id,
            category: req.category,
            title: req.title,
            status: found ? 'passed' : 'warning',
            currentValueDescription: found ? 'Found keyword' : 'Keyword not found',
            expectedValueDescription: `Keywords: ${words.slice(0, 3).join(', ')}`,
            fixActionAvailable: false,
            details: found
              ? 'Relevant campaign keywords found in subtitles.'
              : 'Recommended call-to-action keywords not detected in project subtitles.'
          });
          break;
        }

        case 'prohibited_phrase': {
          const forbidden: string[] = Array.isArray(req.expectedValue) ? req.expectedValue : [req.expectedValue];
          const violated = forbidden.filter(phrase => combinedSubtitleText.includes(phrase.toLowerCase()));
          const pass = violated.length === 0;
          checks.push({
            requirementId: req.id,
            category: req.category,
            title: req.title,
            status: pass ? 'passed' : 'warning',
            currentValueDescription: pass ? 'None detected' : `Found: ${violated.join(', ')}`,
            expectedValueDescription: 'Zero prohibited watermarks/phrases',
            fixActionAvailable: false,
            details: pass
              ? 'Clean of prohibited terms or external watermarks.'
              : `Potential prohibited terms found: ${violated.join(', ')}`
          });
          break;
        }
      }
    }

    const totalRules = checks.length;
    const passed = checks.filter(c => c.status === 'passed').length;
    const failedCritical = checks.filter(c => c.status === 'failed').length;
    const warnings = checks.filter(c => c.status === 'warning').length;

    const overallScore = totalRules > 0 ? Math.round((passed / totalRules) * 100) : 0;
    const status = failedCritical === 0 && overallScore >= 80 ? 'compliant' : failedCritical > 0 ? 'rejected' : 'needs_action';

    const disclaimer =
      'LEGAL & REWARDS DISCLAIMER: This offline audit evaluates structural and textual campaign rules based solely on the provided brief and timeline metadata. It does not guarantee payout, algorithmic distribution, or monetization approval by third-party platform operators.';

    return {
      timestamp: new Date().toISOString(),
      briefName: brief.name,
      platform: brief.platform,
      overallScore,
      status,
      summary: {
        totalRules,
        passed,
        failedCritical,
        warnings
      },
      checks,
      legalDisclaimer: disclaimer
    };
  }

  /**
   * Applies an automated fix to the project / subtitles / segments
   */
  public static executeFix(
    fixType: 'reframe_aspect' | 'inject_hashtag' | 'trim_duration' | 'remove_phrase',
    requirement: CampaignRequirement,
    project: Project,
    segments: TimelineSegment[],
    subtitles: SubtitleItem[],
    callbacks: {
      updateProjectAspect: (aspect: AspectRatioType) => void;
      addSubtitle: (item: Omit<SubtitleItem, 'id'>) => void;
      trimLastSegment: (targetMaxSec: number) => void;
    }
  ): { success: boolean; message: string } {
    switch (fixType) {
      case 'reframe_aspect': {
        const targetAspect = requirement.expectedValue as AspectRatioType;
        callbacks.updateProjectAspect(targetAspect);
        return {
          success: true,
          message: `Project aspect ratio successfully updated to ${targetAspect}.`
        };
      }

      case 'inject_hashtag': {
        const tag = Array.isArray(requirement.expectedValue)
          ? requirement.expectedValue[0]
          : requirement.expectedValue;
        
        // Find suitable time: either 1.0s or end of video
        const totalDuration = segments.reduce((max, s) => Math.max(max, s.endTime), 0);
        const startTime = totalDuration > 4 ? totalDuration - 3.5 : 1.0;
        const endTime = Math.min(totalDuration, startTime + 2.5);

        callbacks.addSubtitle({
          projectId: project.id,
          startTime,
          endTime,
          text: `${tag}`,
          textAr: `${tag}`,
          position: 'bottom'
        });

        return {
          success: true,
          message: `Injected required tag "${tag}" as subtitle caption.`
        };
      }

      case 'trim_duration': {
        const targetMax = Number(requirement.expectedValue);
        callbacks.trimLastSegment(targetMax);
        return {
          success: true,
          message: `Trimmed timeline to ${targetMax}s to comply with maximum duration.`
        };
      }

      default:
        return { success: false, message: 'Fix action not supported.' };
    }
  }
}
