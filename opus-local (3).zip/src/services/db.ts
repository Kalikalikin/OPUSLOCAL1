/**
 * IndexedDB storage for Opus Local.
 * Stores Projects, Timeline state, Media items (with ArrayBuffer blobs or persistent URLs),
 * Subtitles, and Export records.
 * 
 * Never loses projects on refresh.
 */

export interface ProjectMetadata {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  aspectRatio: '9:16' | '16:9' | '1:1' | '4:5';
  width: number;
  height: number;
  fps: number;
  durationSec: number;
  thumbnailUrl?: string;
}

export interface MediaAsset {
  id: string;
  name: string;
  size: number;
  type: string;
  durationSec: number;
  width: number;
  height: number;
  blob?: Blob;
  localPath?: string;
  contentUri?: string;
  createdAt: number;
}

export interface TimelineClip {
  id: string;
  mediaId: string;
  name: string;
  sourceDurationSec: number;
  trimStartSec: number;
  trimEndSec: number;
  timelineStartSec: number;
  durationSec: number; // trimEndSec - trimStartSec
  speed: number; // 0.25 - 4.0
  volume: number; // 0.0 - 2.0
  muted: boolean;
  filter: 'none' | 'cinematic' | 'warm' | 'cool' | 'vibrant' | 'bnw' | 'sepia';
  cropFit: 'fit' | 'fill';
  nativeWidth: number;
  nativeHeight: number;
}

export interface SubtitleItem {
  id: string;
  startTimeSec: number;
  endTimeSec: number;
  text: string;
  translation?: string;
  style?: {
    fontSize: number;
    color: string;
    bgColor: string;
    position: 'bottom' | 'middle' | 'top';
  };
}

export interface AudioTrack {
  id: string;
  mediaId: string;
  name: string;
  timelineStartSec: number;
  trimStartSec: number;
  durationSec: number;
  volume: number;
  muted: boolean;
}

export interface ProjectData {
  metadata: ProjectMetadata;
  clips: TimelineClip[];
  subtitles: SubtitleItem[];
  audioTracks: AudioTrack[];
}

export interface ExportRecord {
  id: string;
  projectId: string;
  projectName: string;
  createdAt: number;
  fileBlob?: Blob;
  fileName: string;
  fileSizeBytes: number;
  durationSec: number;
  resolution: string;
  aspectRatio: string;
  localPath?: string;
}

const DB_NAME = 'opus_local_db';
// Version 3 ensures seamless migration from earlier version 1 or 2 without VersionError
const DB_VERSION = 3;

class DatabaseManager {
  private dbPromise: Promise<IDBDatabase> | null = null;

  private async getDB(): Promise<IDBDatabase> {
    if (this.dbPromise) return this.dbPromise;

    this.dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        
        // Projects store
        if (!db.objectStoreNames.contains('projects')) {
          db.createObjectStore('projects', { keyPath: 'metadata.id' });
        }

        // Media files store (stores blobs and persistent references)
        if (!db.objectStoreNames.contains('media_assets')) {
          db.createObjectStore('media_assets', { keyPath: 'id' });
        }

        // Export history store
        if (!db.objectStoreNames.contains('exports')) {
          db.createObjectStore('exports', { keyPath: 'id' });
        }
      };

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });

    return this.dbPromise;
  }

  // --- Project CRUD ---
  async saveProject(project: ProjectData): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('projects', 'readwrite');
      const store = tx.objectStore('projects');
      const req = store.put(project);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  async getProject(id: string): Promise<ProjectData | null> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('projects', 'readonly');
      const store = tx.objectStore('projects');
      const req = store.get(id);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  }

  async getAllProjects(): Promise<ProjectData[]> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('projects', 'readonly');
      const store = tx.objectStore('projects');
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  }

  async deleteProject(id: string): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('projects', 'readwrite');
      const store = tx.objectStore('projects');
      const req = store.delete(id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  // --- Media Assets ---
  async saveMediaAsset(asset: MediaAsset): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('media_assets', 'readwrite');
      const store = tx.objectStore('media_assets');
      const req = store.put(asset);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  async getMediaAsset(id: string): Promise<MediaAsset | null> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('media_assets', 'readonly');
      const store = tx.objectStore('media_assets');
      const req = store.get(id);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  }

  async getAllMediaAssets(): Promise<MediaAsset[]> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('media_assets', 'readonly');
      const store = tx.objectStore('media_assets');
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  }

  async deleteMediaAsset(id: string): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('media_assets', 'readwrite');
      const store = tx.objectStore('media_assets');
      const req = store.delete(id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  // --- Exports History ---
  async saveExportRecord(rec: ExportRecord): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('exports', 'readwrite');
      const store = tx.objectStore('exports');
      const req = store.put(rec);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  async getAllExports(): Promise<ExportRecord[]> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('exports', 'readonly');
      const store = tx.objectStore('exports');
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  }

  async deleteExportRecord(id: string): Promise<void> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('exports', 'readwrite');
      const store = tx.objectStore('exports');
      const req = store.delete(id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }
}

export const dbService = new DatabaseManager();
