/**
 * Android bridge interface contract between WebView React app and native Android Kotlin layer.
 * 
 * Matches NativeMediaBridge.kt implementation:
 * window.AndroidMediaBridge = {
 *   isNativeAvailable: () => boolean,
 *   getDeviceInfo: () => Promise<DeviceInfo>,
 *   requestPermissions: () => Promise<PermissionResult>,
 *   pickMediaFile: () => Promise<PickedMediaFile>,
 *   copyMediaToAppStorage: (sourceUri: string) => Promise<StoredMediaFile>,
 *   startVideoExport: (exportConfigJson: string) => Promise<{ jobId: string }>,
 *   cancelVideoExport: (jobId: string) => Promise<boolean>,
 *   queryExportStatus: (jobId: string) => Promise<ExportProgressResult>,
 *   listSavedExports: () => Promise<SavedExportFile[]>,
 *   openSavedExport: (filePath: string) => Promise<boolean>,
 *   checkModelStatus: (modelId: string) => Promise<ModelStatusResult>
 * }
 */

export interface DeviceInfo {
  manufacturer: string;
  model: string;
  sdkInt: number;
  totalMemoryMb: number;
  availableMemoryMb: number;
  isLowRamDevice: boolean;
  isAndroid: boolean;
  platform: 'android' | 'web';
}

export interface PermissionResult {
  granted: boolean;
  mediaReadGranted: boolean;
  notificationsGranted: boolean;
  deniedPermissions: string[];
}

export interface PickedMediaFile {
  name: string;
  size: number;
  mimeType: string;
  contentUri: string;
  permanentPath?: string;
  durationMs?: number;
  width?: number;
  height?: number;
}

export interface StoredMediaFile {
  id: string;
  originalName: string;
  localPath: string; // Stored in internal app storage (cache or filesDir)
  contentUri: string;
  sizeBytes: number;
  mimeType: string;
  width: number;
  height: number;
  durationMs: number;
}

export interface TimelineClipExportSpec {
  id: string;
  sourceUri: string; // Native file path or content:// or web blob
  trimStartSec: number;
  trimEndSec: number;
  volume: number;
  muted: boolean;
  speed: number;
  rotation?: number;
  mirror?: boolean;
}

export interface SubtitleExportSpec {
  text: string;
  startTimeSec: number;
  endTimeSec: number;
  fontSize?: number;
  colorHex?: string;
  position?: 'bottom' | 'middle' | 'top';
}

export interface NativeExportConfig {
  jobId: string;
  projectName: string;
  outputWidth: number;
  outputHeight: number;
  aspectRatio: '9:16' | '16:9' | '1:1' | '4:5';
  fps: number;
  bitrateBps: number;
  clips: TimelineClipExportSpec[];
  subtitles?: SubtitleExportSpec[];
  audioTracks?: Array<{
    sourceUri: string;
    trimStartSec: number;
    volume: number;
  }>;
}

export interface ExportProgressResult {
  jobId: string;
  progressPercent: number; // 0 - 100
  phase: 'idle' | 'decoding' | 'processing' | 'encoding' | 'muxing' | 'completed' | 'failed' | 'cancelled';
  details?: string;
  outputPath?: string;
  error?: string;
}

export interface SavedExportFile {
  id: string;
  fileName: string;
  filePath: string;
  contentUri: string;
  sizeBytes: number;
  timestamp: number;
  durationSec: number;
  aspectRatio: string;
}

export interface ModelStatusResult {
  modelId: string;
  installed: boolean;
  path?: string;
  sizeBytes?: number;
  compatibility: 'compatible' | 'low_ram_warning' | 'unsupported';
}

declare global {
  interface Window {
    AndroidMediaBridge?: {
      isNativeAvailable?: () => boolean;
      getDeviceInfo?: () => string; // Returns JSON string of DeviceInfo
      requestPermissions?: () => string; // Returns JSON string
      pickMediaFile?: () => string; // Returns JSON string
      copyMediaToAppStorage?: (sourceUri: string) => string; // Returns JSON string
      startVideoExport?: (configJson: string) => string; // Returns JSON string
      cancelVideoExport?: (jobId: string) => string;
      queryExportStatus?: (jobId: string) => string;
      listSavedExports?: () => string;
      openSavedExport?: (filePath: string) => string;
      checkModelStatus?: (modelId: string) => string;
    };
  }
}

/**
 * AndroidBridge wrapper with safe web fallback
 */
export class AndroidBridge {
  static isAvailable(): boolean {
    return typeof window !== 'undefined' && 
      Boolean(window.AndroidMediaBridge && typeof window.AndroidMediaBridge.isNativeAvailable === 'function');
  }

  static async getDeviceInfo(): Promise<DeviceInfo> {
    if (this.isAvailable()) {
      try {
        const raw = window.AndroidMediaBridge!.getDeviceInfo!();
        return JSON.parse(raw);
      } catch (err) {
        console.warn('Native getDeviceInfo error, falling back to Web info:', err);
      }
    }

    // Web fallback info
    const nav = typeof navigator !== 'undefined' ? navigator : ({} as any);
    const mem = (nav as any).deviceMemory ? (nav as any).deviceMemory * 1024 : 4096;
    const isMobile = /Android|iPhone|iPad/i.test(nav.userAgent || '');
    return {
      manufacturer: isMobile ? 'Mobile Browser' : 'Host Browser',
      model: 'Web Environment (PWA / Chrome)',
      sdkInt: 34,
      totalMemoryMb: mem,
      availableMemoryMb: Math.round(mem * 0.7),
      isLowRamDevice: mem <= 4096,
      isAndroid: /Android/i.test(nav.userAgent || ''),
      platform: 'web',
    };
  }

  static async requestPermissions(): Promise<PermissionResult> {
    if (this.isAvailable()) {
      try {
        const raw = window.AndroidMediaBridge!.requestPermissions!();
        return JSON.parse(raw);
      } catch (err) {
        console.warn('Native requestPermissions error:', err);
      }
    }
    return {
      granted: true,
      mediaReadGranted: true,
      notificationsGranted: true,
      deniedPermissions: [],
    };
  }

  static async copyMediaToAppStorage(sourceUri: string): Promise<StoredMediaFile | null> {
    if (this.isAvailable()) {
      try {
        const raw = window.AndroidMediaBridge!.copyMediaToAppStorage!(sourceUri);
        return JSON.parse(raw);
      } catch (err) {
        console.warn('Native copyMediaToAppStorage error:', err);
      }
    }
    return null;
  }

  static async startNativeVideoExport(config: NativeExportConfig): Promise<{ jobId: string; started: boolean }> {
    if (this.isAvailable()) {
      try {
        const json = JSON.stringify(config);
        const res = window.AndroidMediaBridge!.startVideoExport!(json);
        const parsed = JSON.parse(res);
        return { jobId: parsed.jobId || config.jobId, started: true };
      } catch (err) {
        console.error('Failed to start native video export:', err);
        throw err;
      }
    }
    throw new Error('Native AndroidMediaBridge is not available in this environment');
  }

  static async queryExportStatus(jobId: string): Promise<ExportProgressResult | null> {
    if (this.isAvailable()) {
      try {
        const raw = window.AndroidMediaBridge!.queryExportStatus!(jobId);
        return JSON.parse(raw);
      } catch (err) {
        console.error('Failed to query export status:', err);
      }
    }
    return null;
  }

  static async cancelVideoExport(jobId: string): Promise<boolean> {
    if (this.isAvailable()) {
      try {
        const raw = window.AndroidMediaBridge!.cancelVideoExport!(jobId);
        return JSON.parse(raw).success;
      } catch (err) {
        console.error('Failed to cancel video export:', err);
      }
    }
    return false;
  }

  static async listSavedExports(): Promise<SavedExportFile[]> {
    if (this.isAvailable()) {
      try {
        const raw = window.AndroidMediaBridge!.listSavedExports!();
        return JSON.parse(raw);
      } catch (err) {
        console.warn('listSavedExports error:', err);
      }
    }
    return [];
  }
}
