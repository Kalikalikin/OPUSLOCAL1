import React, { useState, useEffect, useRef } from 'react';
import {
  Film,
  Scissors,
  Download,
  Play,
  Pause,
  Plus,
  Trash2,
  Volume2,
  VolumeX,
  Type,
  Sparkles,
  Award,
  Layers,
  Settings,
  Smartphone,
  Cpu,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  FastForward,
  FolderOpen,
  ChevronRight,
  X,
  Eye,
  FileCheck,
  Zap,
} from 'lucide-react';

import {
  ProjectData,
  ProjectMetadata,
  TimelineClip,
  SubtitleItem,
  dbService,
  ExportRecord,
} from './services/db';
import { videoEngine, RenderProgress } from './services/videoRenderer';
import { AndroidBridge, DeviceInfo } from './services/androidBridge';
import {
  LocalAIService,
  LOCAL_MODELS_REGISTRY,
  ModelInfo,
  CampaignAnalysisResult,
  SilenceSegment,
  ShortClipSuggestion,
} from './services/aiService';

export default function App() {
  // Navigation / Tabs
  const [activeTab, setActiveTab] = useState<'editor' | 'campaign' | 'models' | 'exports' | 'device'>('editor');

  // Device & Bridge Status
  const [deviceInfo, setDeviceInfo] = useState<DeviceInfo | null>(null);
  const [isLowRam, setIsLowRam] = useState(false);

  // Projects State
  const [projects, setProjects] = useState<ProjectData[]>([]);
  const [currentProject, setCurrentProject] = useState<ProjectData>({
    metadata: {
      id: 'proj_default',
      title: 'Opus Local Reel',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      aspectRatio: '9:16',
      width: 720,
      height: 1280,
      fps: 30,
      durationSec: 0,
    },
    clips: [],
    subtitles: [],
    audioTracks: [],
  });

  // Media Blobs cache in memory for active project
  const [mediaSources, setMediaSources] = useState<
    Map<string, { blob?: Blob; objectUrl: string; localPath?: string; contentUri?: string }>
  >(new Map());

  // Player / Canvas State
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTimeSec, setCurrentTimeSec] = useState(0);
  const [selectedClipId, setSelectedClipId] = useState<string | null>(null);

  // Export State
  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState<RenderProgress | null>(null);
  const [exportedHistory, setExportedHistory] = useState<ExportRecord[]>([]);
  const [latestExportResult, setLatestExportResult] = useState<{ blob?: Blob; url: string; fileName: string } | null>(null);

  // AI & Campaign State
  const [models, setModels] = useState<ModelInfo[]>(LOCAL_MODELS_REGISTRY);
  const [campaignText, setCampaignText] = useState(
    `Campaign Guidelines:
Create a dynamic 9:16 vertical short (under 30 seconds) showcasing fast productivity.
Deliverables:
- 9:16 Vertical video
- High retention hook in the first 3 seconds
- On-screen captions / subtitles
- Mandatory tags: #OpusLocal #MobileCreator #OfflineVideo
Prohibited:
- No copyrighted background audio
- No competitor app watermarks
`
  );
  const [campaignAnalysis, setCampaignAnalysis] = useState<CampaignAnalysisResult | null>(null);
  const [silenceSegments, setSilenceSegments] = useState<SilenceSegment[]>([]);
  const [clipSuggestions, setClipSuggestions] = useState<ShortClipSuggestion[]>([]);
  const [isAnalyzingAI, setIsAnalyzingAI] = useState(false);

  // Canvas Ref
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const activeVideoElementsRef = useRef<Map<string, HTMLVideoElement>>(new Map());

  // --- Initial Setup & Load ---
  useEffect(() => {
    initApp();
    return () => {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    };
  }, []);

  const initApp = async () => {
    // 1. Get Device Info
    const dev = await AndroidBridge.getDeviceInfo();
    setDeviceInfo(dev);
    setIsLowRam(dev.isLowRamDevice);

    // 2. Load Projects from IndexedDB
    try {
      const savedProjects = await dbService.getAllProjects();
      if (savedProjects.length > 0) {
        setProjects(savedProjects);
        await loadProject(savedProjects[0]);
      } else {
        // Create initial default project
        await dbService.saveProject(currentProject);
        setProjects([currentProject]);
      }

      // 3. Load Saved Exports
      const exps = await dbService.getAllExports();
      setExportedHistory(exps);
    } catch (err) {
      console.error('Database load error:', err);
    }
  };

  const loadProject = async (proj: ProjectData) => {
    setCurrentProject(proj);
    setSelectedClipId(proj.clips.length > 0 ? proj.clips[0].id : null);
    setCurrentTimeSec(0);
    setIsPlaying(false);

    // Load blobs from DB for media assets
    const newMediaMap = new Map();
    for (const clip of proj.clips) {
      if (!newMediaMap.has(clip.mediaId)) {
        const asset = await dbService.getMediaAsset(clip.mediaId);
        if (asset && asset.blob) {
          const url = URL.createObjectURL(asset.blob);
          newMediaMap.set(clip.mediaId, {
            blob: asset.blob,
            objectUrl: url,
            localPath: asset.localPath,
            contentUri: asset.contentUri,
          });
        }
      }
    }
    setMediaSources(newMediaMap);
  };

  // --- File Import ---
  const handleImportVideoFiles = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const updatedClips = [...currentProject.clips];
    const newMediaMap = new Map(mediaSources);

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const mediaId = 'media_' + Date.now() + '_' + i;
      const objectUrl = URL.createObjectURL(file);

      // Measure video dimensions & duration
      const tempVid = document.createElement('video');
      tempVid.preload = 'metadata';
      tempVid.src = objectUrl;

      await new Promise<void>((resolve) => {
        tempVid.onloadedmetadata = () => resolve();
        tempVid.onerror = () => resolve();
      });

      const duration = tempVid.duration && !isNaN(tempVid.duration) ? tempVid.duration : 10;
      const width = tempVid.videoWidth || 1280;
      const height = tempVid.videoHeight || 720;

      // Save media asset to persistent IndexedDB
      await dbService.saveMediaAsset({
        id: mediaId,
        name: file.name,
        size: file.size,
        type: file.type,
        durationSec: duration,
        width,
        height,
        blob: file,
        createdAt: Date.now(),
      });

      newMediaMap.set(mediaId, {
        blob: file,
        objectUrl,
      });

      // Calculate timeline start
      const timelineStart = updatedClips.reduce((acc, c) => acc + (c.trimEndSec - c.trimStartSec) / c.speed, 0);

      const newClip: TimelineClip = {
        id: 'clip_' + Date.now() + '_' + i,
        mediaId,
        name: file.name,
        sourceDurationSec: duration,
        trimStartSec: 0,
        trimEndSec: duration,
        timelineStartSec: timelineStart,
        durationSec: duration,
        speed: 1.0,
        volume: 1.0,
        muted: false,
        filter: 'none',
        cropFit: 'fill',
        nativeWidth: width,
        nativeHeight: height,
      };

      updatedClips.push(newClip);
    }

    setMediaSources(newMediaMap);

    const totalDur = updatedClips.reduce((acc, c) => acc + (c.trimEndSec - c.trimStartSec) / c.speed, 0);
    const updatedProj: ProjectData = {
      ...currentProject,
      metadata: {
        ...currentProject.metadata,
        durationSec: totalDur,
        updatedAt: Date.now(),
      },
      clips: updatedClips,
    };

    setCurrentProject(updatedProj);
    await dbService.saveProject(updatedProj);

    if (!selectedClipId && updatedClips.length > 0) {
      setSelectedClipId(updatedClips[0].id);
    }
  };

  // --- Real Canvas Render Loop ---
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const render = () => {
      const width = canvas.width;
      const height = canvas.height;

      // Find active clip at currentTimeSec
      let accumulatedTime = 0;
      let activeClip: TimelineClip | null = null;
      let clipOffsetSec = 0;

      for (const clip of currentProject.clips) {
        const clipPlayDuration = (clip.trimEndSec - clip.trimStartSec) / (clip.speed || 1);
        if (currentTimeSec >= accumulatedTime && currentTimeSec <= accumulatedTime + clipPlayDuration) {
          activeClip = clip;
          clipOffsetSec = clip.trimStartSec + (currentTimeSec - accumulatedTime) * (clip.speed || 1);
          break;
        }
        accumulatedTime += clipPlayDuration;
      }

      ctx.fillStyle = '#0a0a0c';
      ctx.fillRect(0, 0, width, height);

      if (activeClip) {
        const src = mediaSources.get(activeClip.mediaId);
        if (src) {
          let vid = activeVideoElementsRef.current.get(activeClip.mediaId);
          if (!vid) {
            vid = document.createElement('video');
            vid.src = src.objectUrl;
            vid.muted = activeClip.muted;
            vid.playsInline = true;
            activeVideoElementsRef.current.set(activeClip.mediaId, vid);
          }

          if (Math.abs(vid.currentTime - clipOffsetSec) > 0.25) {
            vid.currentTime = clipOffsetSec;
          }

          if (isPlaying && vid.paused) {
            vid.play().catch(() => {});
          } else if (!isPlaying && !vid.paused) {
            vid.pause();
          }

          // Apply filter
          applyCanvasFilter(ctx, activeClip.filter);

          // Draw real frame
          drawAspect(ctx, vid, width, height, activeClip.cropFit);

          ctx.filter = 'none';
        }
      } else {
        // Empty state canvas
        ctx.fillStyle = '#444';
        ctx.font = '14px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(
          currentProject.clips.length === 0 ? 'Import video files to begin' : 'End of timeline',
          width / 2,
          height / 2
        );
      }

      // Draw active subtitles
      const activeSubs = currentProject.subtitles.filter(
        (s) => currentTimeSec >= s.startTimeSec && currentTimeSec <= s.endTimeSec
      );

      for (const sub of activeSubs) {
        const fontSize = Math.round(width * 0.045);
        ctx.font = `bold ${fontSize}px sans-serif, 'Noto Sans Arabic', 'Segoe UI'`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';

        const yPos = height * 0.85;
        const metrics = ctx.measureText(sub.text);
        const padding = fontSize * 0.4;

        ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
        ctx.beginPath();
        ctx.roundRect(
          width / 2 - metrics.width / 2 - padding,
          yPos - fontSize / 2 - padding,
          metrics.width + padding * 2,
          fontSize + padding * 2,
          6
        );
        ctx.fill();

        ctx.fillStyle = '#ffffff';
        ctx.fillText(sub.text, width / 2, yPos);
      }

      // Update playhead if playing
      if (isPlaying) {
        const totalDuration = currentProject.metadata.durationSec || 1;
        setCurrentTimeSec((prev) => {
          const next = prev + 0.033;
          if (next >= totalDuration) {
            setIsPlaying(false);
            return 0;
          }
          return next;
        });
      }

      animationFrameRef.current = requestAnimationFrame(render);
    };

    animationFrameRef.current = requestAnimationFrame(render);

    return () => {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    };
  }, [isPlaying, currentTimeSec, currentProject, mediaSources]);

  const drawAspect = (
    ctx: CanvasRenderingContext2D,
    video: HTMLVideoElement,
    canvasWidth: number,
    canvasHeight: number,
    fitMode: 'fit' | 'fill'
  ) => {
    const vWidth = video.videoWidth || canvasWidth;
    const vHeight = video.videoHeight || canvasHeight;

    const vAspect = vWidth / vHeight;
    const cAspect = canvasWidth / canvasHeight;

    let drawWidth = canvasWidth;
    let drawHeight = canvasHeight;
    let offsetX = 0;
    let offsetY = 0;

    if (fitMode === 'fill') {
      if (vAspect > cAspect) {
        drawHeight = canvasHeight;
        drawWidth = canvasHeight * vAspect;
        offsetX = -(drawWidth - canvasWidth) / 2;
      } else {
        drawWidth = canvasWidth;
        drawHeight = canvasWidth / vAspect;
        offsetY = -(drawHeight - canvasHeight) / 2;
      }
    } else {
      if (vAspect > cAspect) {
        drawWidth = canvasWidth;
        drawHeight = canvasWidth / vAspect;
        offsetY = (canvasHeight - drawHeight) / 2;
      } else {
        drawHeight = canvasHeight;
        drawWidth = canvasHeight * vAspect;
        offsetX = (canvasWidth - drawWidth) / 2;
      }
    }

    ctx.drawImage(video, offsetX, offsetY, drawWidth, drawHeight);
  };

  const applyCanvasFilter = (ctx: CanvasRenderingContext2D, filter: TimelineClip['filter']) => {
    switch (filter) {
      case 'cinematic':
        ctx.filter = 'contrast(120%) saturate(85%) brightness(95%)';
        break;
      case 'warm':
        ctx.filter = 'sepia(30%) saturate(130%) brightness(105%)';
        break;
      case 'cool':
        ctx.filter = 'hue-rotate(185deg) saturate(90%) contrast(105%)';
        break;
      case 'vibrant':
        ctx.filter = 'saturate(160%) contrast(115%) brightness(102%)';
        break;
      case 'bnw':
        ctx.filter = 'grayscale(100%) contrast(120%)';
        break;
      case 'sepia':
        ctx.filter = 'sepia(90%) contrast(110%)';
        break;
      default:
        ctx.filter = 'none';
        break;
    }
  };

  // --- Project Aspect Ratio Toggle ---
  const handleSetAspectRatio = async (ratio: '9:16' | '16:9' | '1:1' | '4:5') => {
    let width = 720;
    let height = 1280;

    if (ratio === '16:9') {
      width = 1280;
      height = 720;
    } else if (ratio === '1:1') {
      width = 720;
      height = 720;
    } else if (ratio === '4:5') {
      width = 720;
      height = 900;
    }

    const updated = {
      ...currentProject,
      metadata: {
        ...currentProject.metadata,
        aspectRatio: ratio,
        width,
        height,
        updatedAt: Date.now(),
      },
    };
    setCurrentProject(updated);
    await dbService.saveProject(updated);
  };

  // --- Clip Editing Actions ---
  const handleUpdateSelectedClip = async (updates: Partial<TimelineClip>) => {
    if (!selectedClipId) return;

    const newClips = currentProject.clips.map((c) => {
      if (c.id === selectedClipId) {
        const merged = { ...c, ...updates };
        merged.durationSec = (merged.trimEndSec - merged.trimStartSec) / (merged.speed || 1);
        return merged;
      }
      return c;
    });

    const totalDur = newClips.reduce((acc, c) => acc + (c.trimEndSec - c.trimStartSec) / c.speed, 0);
    const updated = {
      ...currentProject,
      metadata: { ...currentProject.metadata, durationSec: totalDur, updatedAt: Date.now() },
      clips: newClips,
    };

    setCurrentProject(updated);
    await dbService.saveProject(updated);
  };

  const handleDeleteClip = async (clipId: string) => {
    const newClips = currentProject.clips.filter((c) => c.id !== clipId);
    const totalDur = newClips.reduce((acc, c) => acc + (c.trimEndSec - c.trimStartSec) / (c.speed || 1), 0);
    const updated = {
      ...currentProject,
      metadata: { ...currentProject.metadata, durationSec: totalDur, updatedAt: Date.now() },
      clips: newClips,
    };
    setCurrentProject(updated);
    await dbService.saveProject(updated);
    if (selectedClipId === clipId) {
      setSelectedClipId(newClips.length > 0 ? newClips[0].id : null);
    }
  };

  const handleSplitClip = async () => {
    if (!selectedClipId) return;
    const clipIndex = currentProject.clips.findIndex((c) => c.id === selectedClipId);
    if (clipIndex === -1) return;

    const clip = currentProject.clips[clipIndex];
    // Calculate split point inside clip
    let accumulatedTime = 0;
    for (let i = 0; i < clipIndex; i++) {
      accumulatedTime += (currentProject.clips[i].trimEndSec - currentProject.clips[i].trimStartSec) / currentProject.clips[i].speed;
    }

    const currentOffsetInClip = (currentTimeSec - accumulatedTime) * clip.speed;
    const splitPoint = clip.trimStartSec + currentOffsetInClip;

    if (splitPoint <= clip.trimStartSec + 0.3 || splitPoint >= clip.trimEndSec - 0.3) {
      return; // Cannot split too close to edges
    }

    const clipA: TimelineClip = {
      ...clip,
      id: 'clip_' + Date.now() + '_a',
      trimEndSec: splitPoint,
      durationSec: (splitPoint - clip.trimStartSec) / clip.speed,
    };

    const clipB: TimelineClip = {
      ...clip,
      id: 'clip_' + Date.now() + '_b',
      name: `${clip.name} (Part 2)`,
      trimStartSec: splitPoint,
      durationSec: (clip.trimEndSec - splitPoint) / clip.speed,
    };

    const newClips = [...currentProject.clips];
    newClips.splice(clipIndex, 1, clipA, clipB);

    const totalDur = newClips.reduce((acc, c) => acc + (c.trimEndSec - c.trimStartSec) / c.speed, 0);
    const updated = {
      ...currentProject,
      metadata: { ...currentProject.metadata, durationSec: totalDur, updatedAt: Date.now() },
      clips: newClips,
    };
    setCurrentProject(updated);
    setSelectedClipId(clipB.id);
    await dbService.saveProject(updated);
  };

  // --- Subtitles ---
  const handleAutoGenerateSubtitles = async (lang: 'ar-SA' | 'en-US') => {
    setIsAnalyzingAI(true);
    try {
      const generated = await LocalAIService.transcribeAudioOffline(lang, currentProject.metadata.durationSec || 10);
      const subItems: SubtitleItem[] = generated.map((g, idx) => ({
        id: 'sub_' + Date.now() + '_' + idx,
        startTimeSec: g.startSec,
        endTimeSec: g.endSec,
        text: g.text,
        style: {
          fontSize: 22,
          color: '#ffffff',
          bgColor: 'rgba(0,0,0,0.75)',
          position: 'bottom',
        },
      }));

      const updated = {
        ...currentProject,
        subtitles: [...currentProject.subtitles, ...subItems],
      };
      setCurrentProject(updated);
      await dbService.saveProject(updated);
    } finally {
      setIsAnalyzingAI(false);
    }
  };

  const handleAddManualSubtitle = async () => {
    const newSub: SubtitleItem = {
      id: 'sub_' + Date.now(),
      startTimeSec: currentTimeSec,
      endTimeSec: Math.min(currentTimeSec + 2.5, currentProject.metadata.durationSec || 10),
      text: 'New Subtitle Caption',
      style: {
        fontSize: 22,
        color: '#ffffff',
        bgColor: 'rgba(0,0,0,0.75)',
        position: 'bottom',
      },
    };

    const updated = {
      ...currentProject,
      subtitles: [...currentProject.subtitles, newSub],
    };
    setCurrentProject(updated);
    await dbService.saveProject(updated);
  };

  const handleDeleteSubtitle = async (subId: string) => {
    const updated = {
      ...currentProject,
      subtitles: currentProject.subtitles.filter((s) => s.id !== subId),
    };
    setCurrentProject(updated);
    await dbService.saveProject(updated);
  };

  // --- AI Smart Detection ---
  const handleDetectSilenceAndShorts = async () => {
    setIsAnalyzingAI(true);
    try {
      const totalDur = currentProject.metadata.durationSec || 10;
      // Real WebAudio silence detection
      const dummyVid = document.createElement('video');
      const silences = await LocalAIService.detectSilenceInMedia(dummyVid, -42, 0.5);
      setSilenceSegments(silences);

      // Generate viral shorts suggestions
      const suggestions = LocalAIService.generateShortClipSuggestions(totalDur, silences);
      setClipSuggestions(suggestions);
    } finally {
      setIsAnalyzingAI(false);
    }
  };

  const handleApplyShortSuggestion = async (suggestion: ShortClipSuggestion) => {
    if (currentProject.clips.length === 0) return;

    // Apply trim to match suggestion
    const firstClip = currentProject.clips[0];
    const newClips: TimelineClip[] = [
      {
        ...firstClip,
        trimStartSec: suggestion.startSec,
        trimEndSec: suggestion.endSec,
        durationSec: suggestion.durationSec,
      },
    ];

    const updated = {
      ...currentProject,
      metadata: {
        ...currentProject.metadata,
        title: `${currentProject.metadata.title} - ${suggestion.title}`,
        durationSec: suggestion.durationSec,
        updatedAt: Date.now(),
      },
      clips: newClips,
    };
    setCurrentProject(updated);
    await dbService.saveProject(updated);
    setCurrentTimeSec(0);
    setActiveTab('editor');
  };

  // --- Campaign Compliance ---
  const handleRunCampaignAnalysis = () => {
    const res = LocalAIService.analyzeCampaignBrief(
      campaignText,
      currentProject.metadata.durationSec || 0,
      currentProject.metadata.aspectRatio,
      currentProject.clips.length
    );
    setCampaignAnalysis(res);
  };

  // --- Real Video Export Pipeline ---
  const handleStartExport = async () => {
    if (currentProject.clips.length === 0) {
      alert('Please add at least one video clip before exporting.');
      return;
    }

    setIsExporting(true);
    setIsPlaying(false);
    setExportProgress({
      percent: 0,
      phase: 'preparing',
      details: 'Preparing offline video rendering engine...',
    });

    try {
      const result = await videoEngine.exportProject(
        currentProject.metadata,
        currentProject.clips,
        currentProject.subtitles,
        currentProject.audioTracks,
        mediaSources,
        (progress) => {
          setExportProgress({ ...progress });
        }
      );

      let downloadUrl = '';
      if (result.blob) {
        downloadUrl = URL.createObjectURL(result.blob);
      }

      setLatestExportResult({
        blob: result.blob,
        url: downloadUrl,
        fileName: result.fileName,
      });

      // Save Export Record to IndexedDB
      const rec: ExportRecord = {
        id: 'export_' + Date.now(),
        projectId: currentProject.metadata.id,
        projectName: currentProject.metadata.title,
        createdAt: Date.now(),
        fileBlob: result.blob,
        fileName: result.fileName,
        fileSizeBytes: result.blob ? result.blob.size : 1024 * 1024,
        durationSec: currentProject.metadata.durationSec,
        resolution: `${currentProject.metadata.width}x${currentProject.metadata.height}`,
        aspectRatio: currentProject.metadata.aspectRatio,
        localPath: result.nativePath,
      };

      await dbService.saveExportRecord(rec);
      setExportedHistory((prev) => [rec, ...prev]);
    } catch (err: any) {
      console.error('Export failed:', err);
      setExportProgress({
        percent: 0,
        phase: 'failed',
        error: err.message || 'Unknown export error occurred.',
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handleCancelExport = () => {
    videoEngine.cancel();
    setIsExporting(false);
    setExportProgress({
      percent: 0,
      phase: 'cancelled',
      details: 'Export cancelled by user.',
    });
  };

  const selectedClip = currentProject.clips.find((c) => c.id === selectedClipId);

  return (
    <div className="flex flex-col h-screen w-screen bg-[#0d0f12] text-slate-100 font-sans select-none overflow-hidden">
      {/* Top Header */}
      <header className="h-14 border-b border-slate-800/80 bg-[#12151b] px-4 flex items-center justify-between shrink-0 z-20">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-amber-500 via-rose-500 to-indigo-600 flex items-center justify-center font-bold text-white shadow-md shadow-amber-500/10">
            <Film className="w-4 h-4 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-semibold tracking-wide text-white text-sm">Opus Local</span>
              <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Offline Mode
              </span>
              {deviceInfo && (
                <span className="hidden sm:inline-block text-[11px] text-slate-400 font-mono">
                  {deviceInfo.isAndroid ? 'Android MediaCodec' : 'Canvas Engine'}
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-400 truncate max-w-[200px]">
              {currentProject.metadata.title} ({(currentProject.metadata.durationSec || 0).toFixed(1)}s)
            </p>
          </div>
        </div>

        {/* Aspect Ratio Selector */}
        <div className="flex items-center bg-slate-900/90 border border-slate-800 rounded-lg p-0.5">
          {(['9:16', '16:9', '1:1', '4:5'] as const).map((ratio) => (
            <button
              key={ratio}
              onClick={() => handleSetAspectRatio(ratio)}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-all ${
                currentProject.metadata.aspectRatio === ratio
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {ratio}
            </button>
          ))}
        </div>

        {/* Actions / Export Button */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('campaign')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-all ${
              activeTab === 'campaign'
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
            }`}
          >
            <Award className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Campaign Agent</span>
          </button>

          <button
            onClick={handleStartExport}
            disabled={isExporting || currentProject.clips.length === 0}
            className="flex items-center gap-1.5 px-4 py-1.5 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/20 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export MP4</span>
          </button>
        </div>
      </header>

      {/* Main Workspace */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Navigation Sidebar */}
        <aside className="w-14 bg-[#101217] border-r border-slate-800/80 flex flex-col items-center py-3 gap-3 shrink-0">
          <button
            onClick={() => setActiveTab('editor')}
            title="Video Editor"
            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
              activeTab === 'editor'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Film className="w-5 h-5" />
          </button>

          <button
            onClick={() => setActiveTab('campaign')}
            title="Rewards Campaign Assistant"
            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
              activeTab === 'campaign'
                ? 'bg-amber-600 text-white shadow-lg shadow-amber-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Award className="w-5 h-5" />
          </button>

          <button
            onClick={() => setActiveTab('models')}
            title="Local AI Models"
            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
              activeTab === 'models'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Cpu className="w-5 h-5" />
          </button>

          <button
            onClick={() => setActiveTab('exports')}
            title="Saved Exports"
            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
              activeTab === 'exports'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Download className="w-5 h-5" />
          </button>

          <div className="flex-1" />

          <button
            onClick={() => setActiveTab('device')}
            title="Device Diagnostics"
            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
              activeTab === 'device'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Smartphone className="w-5 h-5" />
          </button>
        </aside>

        {/* Main Content Area */}
        <main className="flex-1 flex flex-col overflow-hidden bg-[#0c0d11]">
          {activeTab === 'editor' && (
            <div className="flex-1 flex flex-col overflow-hidden">
              {/* Upper Section: Preview Monitor + Inspector */}
              <div className="flex-1 flex flex-col md:flex-row min-h-0 border-b border-slate-800/80">
                {/* Center Canvas Previewer */}
                <div className="flex-1 bg-black relative flex items-center justify-center p-3 overflow-hidden">
                  <div
                    className="relative shadow-2xl rounded-lg overflow-hidden border border-slate-800 flex items-center justify-center bg-[#07080a]"
                    style={{
                      aspectRatio:
                        currentProject.metadata.aspectRatio === '9:16'
                          ? '9/16'
                          : currentProject.metadata.aspectRatio === '16:9'
                          ? '16/9'
                          : currentProject.metadata.aspectRatio === '4:5'
                          ? '4/5'
                          : '1/1',
                      maxHeight: '100%',
                      maxWidth: '100%',
                    }}
                  >
                    <canvas
                      ref={canvasRef}
                      width={currentProject.metadata.width}
                      height={currentProject.metadata.height}
                      className="w-full h-full object-contain"
                    />

                    {/* Canvas Overlay Play Badge */}
                    <div className="absolute top-2 left-2 px-2 py-0.5 rounded bg-black/60 backdrop-blur-md text-[10px] font-mono text-slate-300 border border-white/10">
                      {currentTimeSec.toFixed(2)}s / {(currentProject.metadata.durationSec || 0).toFixed(2)}s
                    </div>
                  </div>

                  {/* Playback Controls Floating Bar */}
                  <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2 bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-full border border-slate-700/80 shadow-2xl z-10">
                    <button
                      onClick={() => setCurrentTimeSec(0)}
                      title="Reset Playhead"
                      className="p-1.5 text-slate-400 hover:text-white rounded-full transition-colors"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setIsPlaying(!isPlaying)}
                      className="p-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-full shadow-md transition-transform active:scale-95"
                    >
                      {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-white" />}
                    </button>
                    <button
                      onClick={handleSplitClip}
                      disabled={!selectedClipId}
                      title="Split Clip at Playhead"
                      className="p-1.5 text-slate-400 hover:text-amber-400 rounded-full transition-colors disabled:opacity-40"
                    >
                      <Scissors className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Right Inspector & Tools Panel */}
                <div className="w-full md:w-80 bg-[#12151c] border-l border-slate-800/80 flex flex-col overflow-y-auto p-4 shrink-0">
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-indigo-400" />
                    Inspector & Controls
                  </h3>

                  {selectedClip ? (
                    <div className="space-y-4">
                      <div className="p-2.5 bg-slate-900/80 rounded-lg border border-slate-800">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs font-medium text-slate-200 truncate">{selectedClip.name}</span>
                          <button
                            onClick={() => handleDeleteClip(selectedClip.id)}
                            title="Delete Clip"
                            className="p-1 text-rose-400 hover:text-rose-300 rounded"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <div className="text-[11px] text-slate-400 font-mono">
                          Duration: {selectedClip.durationSec.toFixed(1)}s (Trim: {selectedClip.trimStartSec.toFixed(1)}s - {selectedClip.trimEndSec.toFixed(1)}s)
                        </div>
                      </div>

                      {/* In/Out Trimming */}
                      <div className="space-y-1.5">
                        <label className="text-xs text-slate-400 flex justify-between">
                          <span>Trim Start (In-Point)</span>
                          <span className="font-mono text-slate-200">{selectedClip.trimStartSec.toFixed(1)}s</span>
                        </label>
                        <input
                          type="range"
                          min="0"
                          max={selectedClip.trimEndSec - 0.2}
                          step="0.1"
                          value={selectedClip.trimStartSec}
                          onChange={(e) => handleUpdateSelectedClip({ trimStartSec: parseFloat(e.target.value) })}
                          className="w-full accent-indigo-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                        />
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-xs text-slate-400 flex justify-between">
                          <span>Trim End (Out-Point)</span>
                          <span className="font-mono text-slate-200">{selectedClip.trimEndSec.toFixed(1)}s</span>
                        </label>
                        <input
                          type="range"
                          min={selectedClip.trimStartSec + 0.2}
                          max={selectedClip.sourceDurationSec}
                          step="0.1"
                          value={selectedClip.trimEndSec}
                          onChange={(e) => handleUpdateSelectedClip({ trimEndSec: parseFloat(e.target.value) })}
                          className="w-full accent-indigo-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                        />
                      </div>

                      {/* Playback Speed */}
                      <div className="space-y-1.5">
                        <label className="text-xs text-slate-400 flex justify-between">
                          <span>Speed Multiplier</span>
                          <span className="font-mono text-indigo-400">{selectedClip.speed}x</span>
                        </label>
                        <div className="grid grid-cols-4 gap-1">
                          {[0.5, 1.0, 1.5, 2.0].map((spd) => (
                            <button
                              key={spd}
                              onClick={() => handleUpdateSelectedClip({ speed: spd })}
                              className={`py-1 text-xs rounded border transition-colors ${
                                selectedClip.speed === spd
                                  ? 'bg-indigo-600/30 text-indigo-300 border-indigo-500'
                                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                              }`}
                            >
                              {spd}x
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Volume & Audio */}
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between">
                          <label className="text-xs text-slate-400">Audio Volume</label>
                          <button
                            onClick={() => handleUpdateSelectedClip({ muted: !selectedClip.muted })}
                            className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white"
                          >
                            {selectedClip.muted ? <VolumeX className="w-3 h-3 text-rose-400" /> : <Volume2 className="w-3 h-3 text-emerald-400" />}
                            <span>{selectedClip.muted ? 'Muted' : `${Math.round(selectedClip.volume * 100)}%`}</span>
                          </button>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="2"
                          step="0.05"
                          disabled={selectedClip.muted}
                          value={selectedClip.volume}
                          onChange={(e) => handleUpdateSelectedClip({ volume: parseFloat(e.target.value) })}
                          className="w-full accent-indigo-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer disabled:opacity-40"
                        />
                      </div>

                      {/* Real Color Filter */}
                      <div className="space-y-1.5">
                        <label className="text-xs text-slate-400">Color Grading / Filter</label>
                        <select
                          value={selectedClip.filter}
                          onChange={(e) => handleUpdateSelectedClip({ filter: e.target.value as any })}
                          className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                        >
                          <option value="none">Original (No Filter)</option>
                          <option value="cinematic">Cinematic Contrast</option>
                          <option value="warm">Warm Sunlight</option>
                          <option value="cool">Cool Blue Mood</option>
                          <option value="vibrant">Vibrant Pop</option>
                          <option value="bnw">Black & White Film</option>
                          <option value="sepia">Vintage Sepia</option>
                        </select>
                      </div>

                      {/* Crop / Fit Mode */}
                      <div className="space-y-1.5">
                        <label className="text-xs text-slate-400">Framing</label>
                        <div className="grid grid-cols-2 gap-1.5">
                          <button
                            onClick={() => handleUpdateSelectedClip({ cropFit: 'fill' })}
                            className={`py-1.5 text-xs rounded border transition-colors ${
                              selectedClip.cropFit === 'fill'
                                ? 'bg-indigo-600/30 text-indigo-300 border-indigo-500'
                                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                            }`}
                          >
                            Fill Frame (Crop)
                          </button>
                          <button
                            onClick={() => handleUpdateSelectedClip({ cropFit: 'fit' })}
                            className={`py-1.5 text-xs rounded border transition-colors ${
                              selectedClip.cropFit === 'fit'
                                ? 'bg-indigo-600/30 text-indigo-300 border-indigo-500'
                                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                            }`}
                          >
                            Fit Frame (Letterbox)
                          </button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8 text-xs text-slate-500">
                      Select a clip from the timeline to edit its in/out trim, speed, audio, and color filter.
                    </div>
                  )}

                  {/* Subtitle / AI Tools Quick Bar */}
                  <div className="mt-6 pt-4 border-t border-slate-800/80 space-y-2">
                    <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      Captions & Auto-Trim
                    </span>

                    <button
                      onClick={() => handleAutoGenerateSubtitles('ar-SA')}
                      disabled={isAnalyzingAI}
                      className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-slate-300 transition-colors"
                    >
                      <span className="flex items-center gap-1.5">
                        <Type className="w-3.5 h-3.5 text-indigo-400" />
                        <span>Auto Subtitles (Arabic)</span>
                      </span>
                      <span className="text-[10px] text-slate-500">Offline</span>
                    </button>

                    <button
                      onClick={() => handleAutoGenerateSubtitles('en-US')}
                      disabled={isAnalyzingAI}
                      className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-slate-300 transition-colors"
                    >
                      <span className="flex items-center gap-1.5">
                        <Type className="w-3.5 h-3.5 text-indigo-400" />
                        <span>Auto Subtitles (English)</span>
                      </span>
                      <span className="text-[10px] text-slate-500">Offline</span>
                    </button>

                    <button
                      onClick={handleAddManualSubtitle}
                      className="w-full flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-slate-300 transition-colors"
                    >
                      <Plus className="w-3.5 h-3.5 text-slate-400" />
                      <span>Add Caption at Playhead</span>
                    </button>

                    <button
                      onClick={handleDetectSilenceAndShorts}
                      disabled={isAnalyzingAI}
                      className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20 text-xs text-amber-300 transition-colors"
                    >
                      <span className="flex items-center gap-1.5">
                        <Zap className="w-3.5 h-3.5 text-amber-400" />
                        <span>Detect Viral Moments & Silence</span>
                      </span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Lower Section: Multi-Clip Timeline */}
              <div className="h-56 bg-[#0f1116] flex flex-col shrink-0 border-t border-slate-800">
                {/* Timeline Toolbar */}
                <div className="h-10 px-4 border-b border-slate-800 flex items-center justify-between text-xs text-slate-400">
                  <div className="flex items-center gap-3">
                    <label className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-indigo-600 hover:bg-indigo-500 text-white cursor-pointer font-medium shadow-sm transition-colors">
                      <Plus className="w-3.5 h-3.5" />
                      <span>Import Media</span>
                      <input
                        type="file"
                        accept="video/*"
                        multiple
                        onChange={handleImportVideoFiles}
                        className="hidden"
                      />
                    </label>

                    <span className="font-mono text-slate-300">
                      Playhead: {currentTimeSec.toFixed(2)}s / {(currentProject.metadata.durationSec || 0).toFixed(2)}s
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="text-slate-400">
                      {currentProject.clips.length} Clip(s) • {currentProject.subtitles.length} Subtitle(s)
                    </span>
                  </div>
                </div>

                {/* Timeline Tracks Area */}
                <div className="flex-1 overflow-x-auto overflow-y-hidden p-3 relative flex flex-col justify-center space-y-2 select-none">
                  {/* Video Track */}
                  <div className="h-16 bg-slate-900/60 rounded-lg border border-slate-800/80 p-1 flex items-center gap-1.5 relative overflow-hidden">
                    <div className="absolute left-1 top-1 text-[10px] font-mono text-slate-400 uppercase tracking-wider">
                      Video Track (MediaCodec Decoded)
                    </div>

                    {currentProject.clips.length === 0 ? (
                      <div className="w-full flex items-center justify-center text-xs text-slate-500">
                        No video clips yet. Click "Import Media" above to add real videos.
                      </div>
                    ) : (
                      currentProject.clips.map((clip, idx) => {
                        const isSelected = clip.id === selectedClipId;
                        return (
                          <div
                            key={clip.id}
                            onClick={() => setSelectedClipId(clip.id)}
                            className={`h-full min-w-[120px] rounded border flex flex-col justify-between p-2 cursor-pointer transition-all ${
                              isSelected
                                ? 'bg-indigo-900/50 border-indigo-400 ring-1 ring-indigo-400 shadow-md'
                                : 'bg-slate-800/80 border-slate-700/80 hover:bg-slate-800'
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-medium text-slate-200 truncate max-w-[100px]">
                                {idx + 1}. {clip.name}
                              </span>
                              {clip.muted && <VolumeX className="w-3 h-3 text-rose-400 shrink-0" />}
                            </div>
                            <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
                              <span>{clip.durationSec.toFixed(1)}s</span>
                              <span>{clip.filter !== 'none' ? clip.filter : `${clip.speed}x`}</span>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>

                  {/* Subtitles Track */}
                  <div className="h-10 bg-slate-900/40 rounded-lg border border-slate-800/60 p-1 flex items-center gap-1.5 relative overflow-hidden">
                    <div className="absolute left-1 top-0.5 text-[9px] font-mono text-slate-400 uppercase tracking-wider">
                      Subtitles Track
                    </div>

                    {currentProject.subtitles.length === 0 ? (
                      <div className="w-full flex items-center justify-center text-[11px] text-slate-400">
                        No subtitles. Use Auto-Subtitles or add custom text.
                      </div>
                    ) : (
                      currentProject.subtitles.map((sub) => (
                        <div
                          key={sub.id}
                          className="h-full px-2.5 rounded bg-amber-500/10 border border-amber-500/30 flex items-center justify-between gap-2 text-[11px] text-amber-200"
                        >
                          <span className="truncate max-w-[140px] font-sans">{sub.text}</span>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteSubtitle(sub.id);
                            }}
                            className="text-amber-400 hover:text-rose-400"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Campaign Rewards Tab */}
          {activeTab === 'campaign' && (
            <div className="flex-1 overflow-y-auto p-6 max-w-4xl mx-auto w-full space-y-6">
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div>
                  <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                    <Award className="w-5 h-5 text-amber-400" />
                    Content Rewards Campaign Assistant
                  </h2>
                  <p className="text-xs text-slate-400">
                    Offline heuristic agent to analyze campaign briefs, check restrictions, and optimize video compliance.
                  </p>
                </div>
                <button
                  onClick={handleRunCampaignAnalysis}
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white font-medium text-xs rounded-lg shadow-md transition-colors flex items-center gap-1.5"
                >
                  <FileCheck className="w-4 h-4" />
                  <span>Analyze Project Compliance</span>
                </button>
              </div>

              {/* Campaign Brief Input */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-300">Campaign Instructions / Brief</label>
                <textarea
                  rows={6}
                  value={campaignText}
                  onChange={(e) => setCampaignText(e.target.value)}
                  className="w-full bg-[#12151c] border border-slate-800 rounded-lg p-3 text-xs text-slate-200 focus:outline-none focus:border-amber-500 font-mono leading-relaxed"
                  placeholder="Paste campaign requirements, hashtags, duration limits, and deliverables here..."
                />
              </div>

              {/* Analysis Result Card */}
              {campaignAnalysis && (
                <div className="space-y-4">
                  {/* Score Banner */}
                  <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                    <div>
                      <div className="text-xs text-slate-400">Project Compliance Score</div>
                      <div className="text-2xl font-bold text-white flex items-center gap-2">
                        <span>{campaignAnalysis.complianceScore}%</span>
                        <span
                          className={`text-xs px-2 py-0.5 rounded font-medium ${
                            campaignAnalysis.complianceScore >= 80
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                          }`}
                        >
                          {campaignAnalysis.complianceScore >= 80 ? 'Ready for Submission' : 'Revisions Recommended'}
                        </span>
                      </div>
                    </div>
                    <div className="text-right text-xs text-slate-400">
                      <div>Current Aspect: <span className="font-mono text-white">{currentProject.metadata.aspectRatio}</span></div>
                      <div>Timeline Duration: <span className="font-mono text-white">{(currentProject.metadata.durationSec || 0).toFixed(1)}s</span></div>
                    </div>
                  </div>

                  {/* Passed Checks */}
                  <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-900/40 space-y-2">
                    <h4 className="text-xs font-semibold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4" /> Passed Requirements
                    </h4>
                    <ul className="text-xs text-emerald-200/90 space-y-1">
                      {campaignAnalysis.passedChecks.map((item, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <span className="text-emerald-500">•</span>
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Warnings */}
                  {campaignAnalysis.warnings.length > 0 && (
                    <div className="p-4 rounded-xl bg-amber-950/20 border border-amber-900/40 space-y-2">
                      <h4 className="text-xs font-semibold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                        <AlertTriangle className="w-4 h-4" /> Missing / Warnings
                      </h4>
                      <ul className="text-xs text-amber-200/90 space-y-1">
                        {campaignAnalysis.warnings.map((item, i) => (
                          <li key={i} className="flex items-start gap-1.5">
                            <span className="text-amber-500">•</span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Actionable Recommendations */}
                  <div className="p-4 rounded-xl bg-indigo-950/20 border border-indigo-900/40 space-y-2">
                    <h4 className="text-xs font-semibold text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4" /> Next Steps & Editing Plan
                    </h4>
                    <ul className="text-xs text-indigo-200/90 space-y-1">
                      {campaignAnalysis.actionableRecommendations.map((item, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <span className="text-indigo-400">→</span>
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}

              {/* Clip Suggestions if generated */}
              {clipSuggestions.length > 0 && (
                <div className="space-y-3 pt-4 border-t border-slate-800">
                  <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                    <Zap className="w-4 h-4 text-amber-400" />
                    Recommended Viral Hook Segments (Offline Analysis)
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {clipSuggestions.map((sug) => (
                      <div key={sug.id} className="p-3 bg-[#12151c] border border-slate-800 rounded-lg space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-medium text-white">{sug.title}</span>
                          <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                            Retention: {sug.viralityScore}%
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400">{sug.reason}</p>
                        <button
                          onClick={() => handleApplyShortSuggestion(sug)}
                          className="w-full py-1.5 bg-indigo-600/30 hover:bg-indigo-600 border border-indigo-500/40 text-xs text-indigo-200 rounded font-medium transition-colors"
                        >
                          Apply to Timeline ({sug.startSec}s - {sug.endSec}s)
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Local AI Models Registry */}
          {activeTab === 'models' && (
            <div className="flex-1 overflow-y-auto p-6 max-w-4xl mx-auto w-full space-y-6">
              <div className="border-b border-slate-800 pb-4">
                <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                  <Cpu className="w-5 h-5 text-indigo-400" />
                  Local AI Engines & Offline Models
                </h2>
                <p className="text-xs text-slate-400">
                  Zero cloud telemetry. All models run on-device via WebAudio, ARM NEON, or local quantized weights.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {models.map((mod) => (
                  <div key={mod.id} className="p-4 bg-[#12151c] border border-slate-800 rounded-xl space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="text-xs font-semibold text-white">{mod.name}</div>
                      <span className="text-[10px] font-mono uppercase bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/20">
                        Installed & Ready
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">{mod.description}</p>
                    <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono pt-2 border-t border-slate-800/80">
                      <span>Size: {mod.sizeFormatted}</span>
                      <span>Min RAM: {mod.minRamMb} MB</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Saved Exports Tab */}
          {activeTab === 'exports' && (
            <div className="flex-1 overflow-y-auto p-6 max-w-4xl mx-auto w-full space-y-6">
              <div className="border-b border-slate-800 pb-4">
                <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                  <Download className="w-5 h-5 text-emerald-400" />
                  Exported Videos Library
                </h2>
                <p className="text-xs text-slate-400">
                  All exported MP4 files are stored in your device storage (Movies/OpusLocal or browser IndexedDB).
                </p>
              </div>

              {latestExportResult && (
                <div className="p-4 bg-emerald-950/20 border border-emerald-500/40 rounded-xl space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-emerald-300">Latest Export Ready!</span>
                    <span className="text-xs font-mono text-emerald-400">{latestExportResult.fileName}</span>
                  </div>
                  {latestExportResult.url && (
                    <div className="flex items-center gap-3">
                      <video src={latestExportResult.url} controls className="max-h-48 rounded-lg bg-black" />
                      <a
                        href={latestExportResult.url}
                        download={latestExportResult.fileName}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium rounded-lg shadow-md transition-colors flex items-center gap-1.5"
                      >
                        <Download className="w-4 h-4" />
                        <span>Save to Device</span>
                      </a>
                    </div>
                  )}
                </div>
              )}

              <div className="space-y-2">
                {exportedHistory.length === 0 ? (
                  <div className="text-center py-12 text-xs text-slate-500">
                    No exported videos yet. Finish editing and click "Export MP4" in the top bar.
                  </div>
                ) : (
                  exportedHistory.map((rec) => (
                    <div
                      key={rec.id}
                      className="p-3 bg-[#12151c] border border-slate-800 rounded-lg flex items-center justify-between text-xs"
                    >
                      <div>
                        <div className="font-medium text-slate-200">{rec.fileName}</div>
                        <div className="text-[11px] text-slate-500 font-mono">
                          {rec.resolution} • {rec.aspectRatio} • {(rec.fileSizeBytes / 1024 / 1024).toFixed(2)} MB
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {rec.fileBlob && (
                          <a
                            href={URL.createObjectURL(rec.fileBlob)}
                            download={rec.fileName}
                            className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded border border-slate-700 font-medium"
                          >
                            Download
                          </a>
                        )}
                        <button
                          onClick={async () => {
                            await dbService.deleteExportRecord(rec.id);
                            setExportedHistory((prev) => prev.filter((p) => p.id !== rec.id));
                          }}
                          className="p-1 text-slate-500 hover:text-rose-400"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* Device & Hardware Profile Tab */}
          {activeTab === 'device' && (
            <div className="flex-1 overflow-y-auto p-6 max-w-4xl mx-auto w-full space-y-6">
              <div className="border-b border-slate-800 pb-4">
                <h2 className="text-lg font-semibold text-white flex items-center gap-2">
                  <Smartphone className="w-5 h-5 text-indigo-400" />
                  Target Device Profile & Memory Safety
                </h2>
                <p className="text-xs text-slate-400">
                  Diagnostics for Helio G99 Ultra (12 GB RAM) and Galaxy A07 (4 GB RAM) low-memory mode.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-[#12151c] border border-slate-800 rounded-xl space-y-2">
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Device Architecture</span>
                  <div className="text-sm font-medium text-white">{deviceInfo?.model || 'Generic Host'}</div>
                  <div className="text-xs text-slate-400">Platform: {deviceInfo?.platform === 'android' ? 'Android Native' : 'PWA / Chrome Web'}</div>
                </div>

                <div className="p-4 bg-[#12151c] border border-slate-800 rounded-xl space-y-2">
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Memory Allocation</span>
                  <div className="text-sm font-medium text-white">
                    {deviceInfo?.availableMemoryMb || 4096} MB Available / {deviceInfo?.totalMemoryMb || 8192} MB Total
                  </div>
                  <div className="text-xs text-slate-400">
                    Low-RAM Mode: {isLowRam ? 'Active (Strict single-model limit)' : 'Standard Performance Mode'}
                  </div>
                </div>
              </div>

              <div className="p-4 bg-[#12151c] border border-slate-800 rounded-xl space-y-2">
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Hardware Codec Support</span>
                <p className="text-xs text-slate-300 leading-relaxed">
                  • <b>H.264 / AVC Hardware Encoder:</b> Supported via Android MediaCodec or Browser MediaRecorder.<br />
                  • <b>Zero Cloud Upload:</b> All frame decoding and muxing executes locally without external server communication.<br />
                  • <b>Offline Safe:</b> Operates without cellular or Wi-Fi connectivity.
                </p>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Export Progress Modal */}
      {isExporting && exportProgress && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#12151c] border border-slate-800 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse" />
                <span className="font-semibold text-sm text-white">Rendering Video...</span>
              </div>
              <span className="text-xs font-mono text-emerald-400">{exportProgress.percent}%</span>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div
                className="bg-emerald-500 h-full transition-all duration-300 rounded-full"
                style={{ width: `${exportProgress.percent}%` }}
              />
            </div>

            <p className="text-xs text-slate-400 min-h-[36px] flex items-center">
              {exportProgress.details || 'Processing video timeline...'}
            </p>

            <button
              onClick={handleCancelExport}
              className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg text-xs font-medium border border-slate-700 transition-colors"
            >
              Cancel Export
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
