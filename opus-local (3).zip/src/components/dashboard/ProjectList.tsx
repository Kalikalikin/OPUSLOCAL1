import React, { useState, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { AspectRatioType } from '../../types/project';
import { localDB } from '../../services/db';
import {
  Plus,
  Play,
  Copy,
  Trash2,
  Download,
  Upload,
  Sparkles,
  Smartphone,
  Monitor,
  Square,
  Search,
  Clock,
  Layers
} from 'lucide-react';

export const ProjectList: React.FC = () => {
  const {
    t,
    projects,
    openProject,
    deleteProject,
    duplicateProject,
    createNewProject,
    generateSampleDemoProject,
    loadProjects,
    addToast
  } = useApp();

  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [selectedAspect, setSelectedAspect] = useState<AspectRatioType>('9:16');
  const [searchQuery, setSearchQuery] = useState('');
  const [isGeneratingDemo, setIsGeneratingDemo] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const filteredProjects = (projects || []).filter(p =>
    (p?.title || 'Untitled Video').toLowerCase().includes((searchQuery || '').toLowerCase())
  );

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    await createNewProject(newTitle || 'Untitled Video', selectedAspect);
    setIsCreateModalOpen(false);
    setNewTitle('');
  };

  const handleGenerateDemo = async () => {
    setIsGeneratingDemo(true);
    try {
      await generateSampleDemoProject();
    } finally {
      setIsGeneratingDemo(false);
    }
  };

  const handleExportBackup = async () => {
    try {
      const jsonStr = await localDB.exportFullDatabaseBackup();
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `opus_local_backup_${Date.now()}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      addToast('success', 'Database backup downloaded.');
    } catch (e: any) {
      addToast('error', `Backup failed: ${e.message}`);
    }
  };

  const handleImportBackup = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const text = await file.text();
      const data = JSON.parse(text);
      if (data.projects && Array.isArray(data.projects)) {
        for (const item of data.projects) {
          if (item.project) await localDB.saveProject(item.project);
          if (item.segments) await localDB.saveTimelineSegments(item.project.id, item.segments);
          if (item.subtitles) await localDB.saveSubtitles(item.project.id, item.subtitles);
        }
        await loadProjects();
        addToast('success', `${data.projects.length} projects restored.`);
      }
    } catch (err: any) {
      addToast('error', `Import failed: ${err.message}`);
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      {/* Action Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
            {t.appName}
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            {t.appSubtitle}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* New Project Button */}
          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-semibold text-xs transition-colors shadow-lg shadow-sky-500/20 active:scale-[0.98]"
          >
            <Plus className="w-4 h-4" />
            <span>{t.newProject}</span>
          </button>

          {/* Offline Sample Demo Generator */}
          <button
            onClick={handleGenerateDemo}
            disabled={isGeneratingDemo}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-colors disabled:opacity-50"
            title="Generates synthetic playable demo video with audio"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>{isGeneratingDemo ? 'Generating...' : t.createSampleProject}</span>
          </button>

          {/* Backup & Restore */}
          <button
            onClick={handleExportBackup}
            className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 transition-colors"
            title={t.exportBackup}
          >
            <Download className="w-4 h-4" />
          </button>

          <label
            className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 transition-colors cursor-pointer"
            title={t.importBackup}
          >
            <Upload className="w-4 h-4" />
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              className="hidden"
              onChange={handleImportBackup}
            />
          </label>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="py-5 flex items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3 rtl:left-auto rtl:right-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder={t.projectTitle}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 rtl:pl-4 rtl:pr-9 pr-4 py-2 bg-slate-900/80 border border-slate-800 rounded-xl text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-sky-500/50"
          />
        </div>

        <div className="text-xs text-slate-400 font-mono">
          <span>{filteredProjects.length}</span> {t.clipsCount}
        </div>
      </div>

      {/* Projects Grid */}
      {filteredProjects.length === 0 ? (
        <div className="p-12 text-center border border-dashed border-slate-800 rounded-2xl bg-slate-900/20 my-4">
          <div className="w-12 h-12 rounded-2xl bg-slate-800/80 border border-slate-700/60 flex items-center justify-center mx-auto text-slate-400 mb-4">
            <Layers className="w-6 h-6" />
          </div>
          <h3 className="text-base font-semibold text-white mb-1">
            {t.noProjects}
          </h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto mb-6">
            {t.noProjectsDesc}
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <button
              onClick={() => setIsCreateModalOpen(true)}
              className="px-4 py-2 rounded-xl bg-sky-500 text-slate-950 font-semibold text-xs shadow-md shadow-sky-500/20 hover:bg-sky-400 transition-colors"
            >
              {t.newProject}
            </button>
            <button
              onClick={handleGenerateDemo}
              disabled={isGeneratingDemo}
              className="px-4 py-2 rounded-xl bg-slate-800 text-slate-200 font-medium text-xs hover:bg-slate-700 transition-colors border border-slate-700"
            >
              {t.createSampleProject}
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredProjects.map((p) => {
            const isVertical = p.aspectRatio === '9:16';
            const isLandscape = p.aspectRatio === '16:9';
            const formattedDate = new Date(p.updatedAt).toLocaleDateString(undefined, {
              month: 'short',
              day: 'numeric'
            });

            return (
              <div
                key={p.id}
                className="group flex flex-col bg-slate-900/60 hover:bg-slate-900 border border-slate-800 hover:border-slate-700/80 rounded-2xl overflow-hidden transition-all duration-200"
              >
                {/* Project preview header thumbnail placeholder */}
                <div
                  onClick={() => openProject(p.id)}
                  className="relative aspect-video bg-slate-950/80 cursor-pointer overflow-hidden flex items-center justify-center group-hover:brightness-105"
                >
                  <div className="flex flex-col items-center gap-2 text-slate-600 group-hover:text-sky-400 transition-colors">
                    {isVertical && <Smartphone className="w-8 h-8" />}
                    {isLandscape && <Monitor className="w-8 h-8" />}
                    {!isVertical && !isLandscape && <Square className="w-8 h-8" />}
                    <span className="text-[11px] font-mono tracking-wider font-semibold">
                      {p.aspectRatio}
                    </span>
                  </div>

                  {/* Play trigger overlay */}
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                    <div className="w-10 h-10 rounded-full bg-sky-500 text-slate-950 flex items-center justify-center shadow-lg transform group-hover:scale-105 transition-transform">
                      <Play className="w-5 h-5 ml-0.5" />
                    </div>
                  </div>

                  {/* Duration badge */}
                  <div className="absolute bottom-2 right-2 rtl:right-auto rtl:left-2 px-2 py-0.5 rounded bg-black/75 text-[10px] font-mono text-slate-200">
                    {p.duration.toFixed(1)}s
                  </div>
                </div>

                {/* Card body */}
                <div className="p-3.5 flex flex-col justify-between flex-1 gap-3">
                  <div>
                    <h3
                      onClick={() => openProject(p.id)}
                      className="text-sm font-semibold text-white hover:text-sky-400 cursor-pointer truncate"
                      title={p.title}
                    >
                      {p.title}
                    </h3>
                    <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-1">
                      <Clock className="w-3 h-3 text-slate-500" />
                      <span>{formattedDate}</span>
                      <span>·</span>
                      <span className="uppercase text-[10px] font-mono text-slate-500">
                        {p.scaleMode}
                      </span>
                    </div>
                  </div>

                  {/* Actions bar */}
                  <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-xs">
                    <button
                      onClick={() => openProject(p.id)}
                      className="text-xs font-medium text-sky-400 hover:text-sky-300"
                    >
                      {t.openProject}
                    </button>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => duplicateProject(p.id)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800"
                        title={t.duplicateProject}
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => deleteProject(p.id)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800"
                        title={t.deleteProject}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* New Project Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-2xl">
            <h2 className="text-base font-bold text-white mb-4">
              {t.newProject}
            </h2>

            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  {t.projectTitle}
                </label>
                <input
                  type="text"
                  required
                  placeholder="My TikTok Reel / YouTube Short"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-sky-500"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-2">
                  {t.aspectRatio}
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: '9:16', label: '9:16 Vertical', icon: Smartphone, desc: 'TikTok / Reels' },
                    { id: '16:9', label: '16:9 Landscape', icon: Monitor, desc: 'YouTube' },
                    { id: '1:1', label: '1:1 Square', icon: Square, desc: 'Feed / Post' }
                  ].map((item) => {
                    const Icon = item.icon;
                    const isSelected = selectedAspect === item.id;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => setSelectedAspect(item.id as AspectRatioType)}
                        className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition-all ${
                          isSelected
                            ? 'bg-sky-500/10 border-sky-500 text-sky-400'
                            : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                        }`}
                      >
                        <Icon className="w-5 h-5 mb-1.5" />
                        <span className="text-xs font-semibold block">{item.id}</span>
                        <span className="text-[10px] text-slate-500 block">{item.desc}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-white"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-semibold bg-sky-500 hover:bg-sky-400 text-slate-950 transition-colors shadow-md shadow-sky-500/20"
                >
                  {t.createProject}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
