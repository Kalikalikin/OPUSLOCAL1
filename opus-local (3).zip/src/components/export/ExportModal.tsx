import React, { useState, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { ExportSettings } from '../../types/project';
import { VideoRenderEngine, RenderProgress, RenderResult } from '../../services/videoRenderer';
import { androidBridge } from '../../services/androidBridge';
import {
  Download,
  X,
  Play,
  CheckCircle2,
  AlertTriangle,
  Loader2,
  Film,
  Type,
  ExternalLink,
  ShieldCheck,
  Info
} from 'lucide-react';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({ isOpen, onClose }) => {
  const {
    t,
    activeProject,
    clips,
    segments,
    subtitles,
    deviceProfile,
    addToast
  } = useApp();

  const isNative = androidBridge.isNativeApp();

  const [settings, setSettings] = useState<ExportSettings>({
    format: 'mp4',
    resolution: deviceProfile.maxPreviewResolution === '480p' ? '480p' : '1080p',
    fps: 30,
    videoBitrateKbps: deviceProfile.exportBitrateKbps || 5000,
    audioBitrateKbps: 128,
    burnSubtitles: true,
    subtitleFontSize: 38,
    subtitleColor: '#ffffff',
    subtitleBg: true
  });

  const [isRendering, setIsRendering] = useState(false);
  const [progress, setProgress] = useState<RenderProgress | null>(null);
  const [renderResult, setRenderResult] = useState<RenderResult | null>(null);
  const rendererRef = useRef<VideoRenderEngine | null>(null);

  if (!isOpen || !activeProject) return null;

  const handleStartRender = async () => {
    setIsRendering(true);
    setRenderResult(null);
    rendererRef.current = new VideoRenderEngine();

    try {
      const result = await rendererRef.current.renderProject(
        activeProject,
        clips,
        segments,
        subtitles,
        settings,
        deviceProfile,
        (p) => setProgress(p)
      );

      setRenderResult(result);
      addToast('success', t.exportComplete);
    } catch (err: any) {
      if (err.message?.includes('cancelled')) {
        addToast('info', 'Render cancelled.');
      } else {
        addToast('error', `${t.exportError}: ${err.message}`);
      }
    } finally {
      setIsRendering(false);
    }
  };

  const handleCancelRender = () => {
    if (rendererRef.current) {
      rendererRef.current.cancel();
    }
  };

  const handleDownloadWebBlob = () => {
    if (!renderResult?.blob) return;
    const a = document.createElement('a');
    a.href = URL.createObjectURL(renderResult.blob);
    const cleanTitle = (activeProject?.title || 'opus_video').toLowerCase().replace(/\s+/g, '_');
    a.download = `${cleanTitle}_${Date.now()}.${renderResult.actualFormat}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleOpenMediaStore = () => {
    if (renderResult?.mediaStoreUri) {
      androidBridge.openMediaStoreUri(renderResult.mediaStoreUri);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
          <div className="flex items-center gap-2">
            <Film className="w-5 h-5 text-sky-400" />
            <div>
              <h2 className="text-base font-bold text-white">
                {t.renderTitle}
              </h2>
              <span className="text-[10px] text-slate-400 block font-mono">
                {isNative ? 'Android MediaCodec Engine' : 'Web Preview Engine (Audio Preserved)'}
              </span>
            </div>
          </div>
          {!isRendering && (
            <button onClick={onClose} className="p-1 rounded text-slate-400 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Modal Body */}
        <div className="space-y-4 overflow-y-auto pr-1">
          {/* Format & Resolution Grid */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {t.resolution}
              </label>
              <select
                disabled={isRendering}
                value={settings.resolution}
                onChange={(e) =>
                  setSettings({ ...settings, resolution: e.target.value as any })
                }
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-sky-500 disabled:opacity-50 font-mono"
              >
                <option value="1080p">1080p (Full HD)</option>
                <option value="720p">720p (HD Balanced)</option>
                <option value="480p">480p (Lightweight SD)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {t.format}
              </label>
              <select
                disabled={isRendering}
                value={settings.format}
                onChange={(e) =>
                  setSettings({ ...settings, format: e.target.value as any })
                }
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-sky-500 disabled:opacity-50 font-mono"
              >
                <option value="mp4">MP4 (H.264 / AVC)</option>
                <option value="webm">WebM (VP9 / Opus)</option>
              </select>
            </div>
          </div>

          {/* Bitrate & FPS */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {t.frameRate}
              </label>
              <select
                disabled={isRendering}
                value={settings.fps}
                onChange={(e) =>
                  setSettings({ ...settings, fps: parseInt(e.target.value) as any })
                }
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-sky-500 disabled:opacity-50 font-mono"
              >
                <option value="30">30 FPS (Standard Mobile)</option>
                <option value="60">60 FPS (Ultra Smooth)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {t.bitrate}
              </label>
              <select
                disabled={isRendering}
                value={settings.videoBitrateKbps}
                onChange={(e) =>
                  setSettings({ ...settings, videoBitrateKbps: parseInt(e.target.value) })
                }
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-sky-500 disabled:opacity-50 font-mono"
              >
                <option value="8000">8.0 Mbps (Ultra Quality)</option>
                <option value="5000">5.0 Mbps (Social Quality)</option>
                <option value="2500">2.5 Mbps (Lightweight Safe)</option>
              </select>
            </div>
          </div>

          {/* Subtitles Burn-in toggle */}
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Type className="w-4 h-4 text-amber-400" />
              <div>
                <span className="text-xs font-semibold text-white block">
                  {t.burnSubtitlesInExport}
                </span>
                <span className="text-[10px] text-slate-400 block">
                  Burns English &amp; Arabic subtitles into video frames
                </span>
              </div>
            </div>
            <input
              type="checkbox"
              disabled={isRendering}
              checked={settings.burnSubtitles}
              onChange={(e) => setSettings({ ...settings, burnSubtitles: e.target.checked })}
              className="w-4 h-4 accent-sky-500 rounded cursor-pointer"
            />
          </div>

          {/* Rendering Progress View */}
          {isRendering && progress && (
            <div className="p-4 rounded-xl bg-sky-950/40 border border-sky-500/40 space-y-2.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-sky-300 flex items-center gap-1.5">
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  {t.renderingProgress}
                </span>
                <span className="font-mono text-sky-400 font-bold">
                  {progress.percent}%
                </span>
              </div>

              {/* Progress Bar */}
              <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                <div
                  className="h-full bg-sky-500 rounded-full transition-all duration-150"
                  style={{ width: `${progress.percent}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
                <span>{progress.currentSecond}s / {progress.totalDuration.toFixed(1)}s</span>
                <span className="uppercase text-[10px] text-sky-400">{progress.status}</span>
              </div>
            </div>
          )}

          {/* Completed State */}
          {renderResult && (
            <div className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-500/50 space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  <div>
                    <span className="text-xs font-bold text-emerald-300 block">
                      {t.exportComplete}
                    </span>
                    <span className="text-[11px] font-mono text-slate-300">
                      {renderResult.fileSizeMb} MB · {renderResult.actualFormat.toUpperCase()} · {settings.resolution}
                    </span>
                  </div>
                </div>

                {isNative && renderResult.mediaStoreUri ? (
                  <button
                    onClick={handleOpenMediaStore}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold shadow-lg transition-colors"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>Open in Gallery</span>
                  </button>
                ) : (
                  <button
                    onClick={handleDownloadWebBlob}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold shadow-lg transition-colors"
                  >
                    <Download className="w-4 h-4" />
                    <span>{t.downloadVideo}</span>
                  </button>
                )}
              </div>

              {/* Output Location & Environment details */}
              {isNative && renderResult.mediaStoreUri && (
                <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-[10px] font-mono text-slate-300">
                  <span className="text-slate-500 block">Android MediaStore URI:</span>
                  <span className="text-emerald-400 break-all">{renderResult.mediaStoreUri}</span>
                  <span className="text-slate-500 block mt-1">Directory: Movies/OpusLocal</span>
                </div>
              )}

              {renderResult.environmentNotice && (
                <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-[10px] text-slate-400 flex items-start gap-1.5">
                  <Info className="w-3.5 h-3.5 text-sky-400 shrink-0 mt-0.5" />
                  <span>{renderResult.environmentNotice}</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="pt-4 mt-4 border-t border-slate-800 flex items-center justify-between gap-2">
          {isRendering ? (
            <button
              onClick={handleCancelRender}
              className="px-4 py-2 rounded-xl bg-rose-950 hover:bg-rose-900 text-rose-300 text-xs font-medium border border-rose-800/80 transition-colors ml-auto"
            >
              {t.cancelExport}
            </button>
          ) : (
            <>
              <button
                onClick={onClose}
                className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-white"
              >
                {t.close}
              </button>

              <button
                onClick={handleStartRender}
                className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs transition-colors shadow-lg shadow-sky-500/20 active:scale-95"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>{t.startExport}</span>
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
